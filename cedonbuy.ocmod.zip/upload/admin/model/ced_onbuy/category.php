<?php

class ModelCedOnbuyCategory extends Model {

	public function getCedonbuyCategory($data = array()) {
		$sql = "SELECT * FROM " . DB_PREFIX . "cedonbuy_category WHERE category_id > '0'";

		if (!empty($data['filter_id'])) {
			$sql .= " AND category_id = '" . (int)$data['filter_id'] . "'";
		}

		if (!empty($data['filter_name'])) {
			$sql .= " AND name LIKE '%" . html_entity_decode($data['filter_name']) . "%'";
		}

		$sql .= " GROUP BY category_id";

		$sort_data = array(
			'name',
			'category_id'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY category_id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}
        
		$query = $this->db->query($sql);

		return $query->rows;
	}

	public function getTotalCedonbuyCategory($data = array()) {
		
		$sql = " SELECT COUNT(DISTINCT category_id) AS total FROM " . DB_PREFIX . "cedonbuy_category WHERE category_id > '0' ";

		if (!empty($data['filter_id'])) {
			$sql .= " AND category_id = '" . (int)$data['filter_id'] . "'";
		}

		if (!empty($data['filter_name'])) {
			$sql .= " AND name LIKE '%" . html_entity_decode($data['filter_name']) . "%'";
		}

        $query = $this->db->query($sql);
        
		return $query->row['total'];
	}

	public function addCategories($category_data = array())
	{
		if(isset($category_data) && is_array($category_data) && $category_data)
		{
			foreach($category_data as $key => $category)
			{
				if(isset($category['google_category']) && !empty($category['google_category']))
	        	{
	        		$google_category = $category['google_category'];
	        	} else {
	        		$google_category = array();
	        	}

				$categoryIsParent = $this->db->query("SELECT `name` FROM " . DB_PREFIX . "cedonbuy_category WHERE category_id = '" . (int)$category['parent_id'] . "'");
		        if($categoryIsParent->num_rows) 
		        { 
		        	$this->db->query("INSERT INTO " . DB_PREFIX . "cedonbuy_category SET 
			        	category_id = '" . (int)$category['category_id'] . "', 
			        	name = '" . strip_tags(html_entity_decode($this->db->escape($categoryIsParent->row['name'].' > '.$category['name']), ENT_QUOTES, 'UTF-8')) ."',
			        	category_tree = '". $this->db->escape($category['category_tree']) ."',
			        	category_type_id = '". (int) $category['category_type_id'] ."',
			        	category_type = '". $this->db->escape($category['category_type']) ."',
			        	parent_id = '" . (int)$category['parent_id'] . "',
			        	lvl = '". (int) $category['lvl'] ."',
			        	product_code_required = '". (int) $category['product_code_required'] ."',
			        	can_list_in = '" . (int)$category['can_list_in'] . "', 
			        	commission_tier_id = '" . (int)$category['commission_tier_id'] . "',
			        	google_category = '". $this->db->escape(json_encode($google_category)) ."'
		        	");
		        } else {
		        	$this->db->query("INSERT INTO " . DB_PREFIX . "cedonbuy_category SET 
			        	category_id = '" . (int)$category['category_id'] . "', 
			        	name = '" . strip_tags(html_entity_decode($this->db->escape($category['name']), ENT_QUOTES, 'UTF-8')). "',
			        	category_tree = '". $this->db->escape($category['category_tree']) ."',
			        	category_type_id = '". (int) $category['category_type_id'] ."',
			        	category_type = '". $this->db->escape($category['category_type']) ."',
			        	parent_id = '" . (int)$category['parent_id'] . "',
			        	lvl = '". (int) $category['lvl'] ."',
			        	product_code_required = '". (int) $category['product_code_required'] ."',
			        	can_list_in = '" . (int)$category['can_list_in'] . "', 
			        	commission_tier_id = '" . (int)$category['commission_tier_id'] . "',
			        	google_category = '". $this->db->escape(json_encode($google_category)) ."'
		        	");
		        }
			}
		}
	}

	public function getAttributes($category_id, $offset = 0) 
	{
		if ($category_id) 
		{
			$results = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedonbuy_attribute` WHERE category_id = '" . (int) $category_id . "' ");
			if ($results && $results->num_rows) {
				return $results->rows;
			} else {
				//$this->load->model('cedshopee/logistics');
				$url = 'categories/'. $category_id . '/technical-details';
				$params = array(
					'site_id' => $this->config->get('ced_onbuy_site_id'),
					'limit'  => '10',
					'offset' => $offset,
					);

				$this->load->library('cedonbuy');
        		$cedonbuy = Cedonbuy::getInstance($this->registry);
        		$access_token = $this->config->get('ced_onbuy_access_token');
		        $access_token_expiry = $this->config->get('ced_onbuy_expires_at');
		        $now = strtotime(date('Y-m-d h:i:s a'));
		        
		        if(!empty($access_token) && !empty($access_token_expiry) && $access_token_expiry > $now)
		        {
		        	$cedonbuy->updateAccessToken();
		        }
				$response = $cedonbuy->getRequest($url, $params);

				if (isset($response['status']) && $response['status'] == true) 
				{
					$response = $response['response'];
					$total_rows = count($response['results']);
					$this->addAttributes($category_id, $response['results']);
					$results = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedonbuy_attribute` WHERE category_id = '" . (int) $category_id . "' ");
					if($total_rows >= '10')
					{
						$noOfAttributesToSkip = $offset + '10';
		            	$this->getAttributes($noOfAttributesToSkip);
					}
					return $results;
				} else {
					return array();
				}
			}
		} else {
			return array();
		}
	}

	public function addAttributes($category_id, $data) 
	{
		//echo '<pre>'; print_r($data); die;
		$this->db->query("DELETE FROM " . DB_PREFIX . "cedonbuy_attribute WHERE category_id = '" . (int)$category_id . "'");
		foreach ($data as $attribute) 
		{
			$group_id = $attribute['group_id'];
			$group_name = $attribute['group_name'];
			foreach($attribute['options'] as $key => $options)
			{
				$this->db->query("INSERT INTO " . DB_PREFIX . "cedonbuy_attribute SET group_id = '" . (int)$group_id . "', group_name = '" . strip_tags(html_entity_decode($this->db->escape($group_name), ENT_QUOTES, 'UTF-8')) . "', is_mandatory = '1', detail_id = '". (int) $options['detail_id'] ."', name = '". strip_tags(html_entity_decode($this->db->escape($options['name']), ENT_QUOTES, 'UTF-8')) ."', options = '" . $this->db->escape(json_encode($options['units'])) . "', category_id = '" . (int)$category_id . "' ");
			}
		}
	}

	public function getFeatures($category_id, $offset = 0) 
	{
		if ($category_id) 
		{
			$results = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedonbuy_feature` WHERE category_id = '" . (int) $category_id . "' ");
			if ($results && $results->num_rows) {
				return $results->rows;
			} else {
				//$this->load->model('cedshopee/logistics');
				$url = 'categories/'. $category_id . '/features';
				$params = array(
					'site_id' => $this->config->get('ced_onbuy_site_id'),
					'limit'  => '10',
					'offset' => $offset,
					);

				$this->load->library('cedonbuy');
        		$cedonbuy = Cedonbuy::getInstance($this->registry);
        		$access_token = $this->config->get('ced_onbuy_access_token');
		        $access_token_expiry = $this->config->get('ced_onbuy_expires_at');
		        $now = strtotime(date('Y-m-d h:i:s a'));
		        
		        // if(!empty($access_token) && !empty($access_token_expiry) && $access_token_expiry > $now)
		        // {
		        	$cedonbuy->updateAccessToken();
		        // }
				$response = $cedonbuy->getRequest($url, $params);

				if (isset($response['status']) && $response['status'] == true) 
				{
					$response = $response['response'];
					$total_rows = count($response['results']);
					$this->addFeatures($category_id, $response['results']);
					$results = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedonbuy_feature` WHERE category_id = '" . (int) $category_id . "' ");
					if($total_rows >= '10')
					{
						$noOfAttributesToSkip = $offset + '10';
		            	$this->getFeatures($noOfAttributesToSkip);
					}
					return $results;
				} else {
					return array();
				}
			}
		} else {
			return array();
		}
	}

	public function addFeatures($category_id, $data) 
	{
		$this->db->query("DELETE FROM " . DB_PREFIX . "cedonbuy_feature WHERE category_id = '" . (int)$category_id . "'");
		foreach ($data as $feature) 
		{
			$this->db->query("INSERT INTO " . DB_PREFIX . "cedonbuy_feature SET group_id = '" . (int)$feature['group_id'] . "', is_mandatory = '". (int) $feature['required'] ."', feature_id = '". (int) $feature['feature_id'] ."', name = '". strip_tags(html_entity_decode($this->db->escape($feature['name']), ENT_QUOTES, 'UTF-8')) ."', options = '" . $this->db->escape(json_encode($feature['options'])) . "', category_id = '" . (int)$category_id . "' ");
			
		}
	}

	public function getBrands($catId, $attribute_id, $brandName, $variant_key)
    {
        $brandArray = array();
        $response = $this->db->query("SELECT * FROM `".DB_PREFIX."cedonbuy_variants` WHERE category_id='".$catId."' AND feature_id = '". $attribute_id . "' AND `variant_key` = '". $this->db->escape($variant_key) ."' ");
        if($response->num_rows)
        {
        	$responses = $response->rows;
        } else {
        	$responses = $this->fetchVariants($catId, $attribute_id, $variant_key);
        }

        if(isset($responses) && is_array($responses) && $responses)
        {
        	foreach ($responses->rows as $res) 
	        {
	        	$options = json_decode($res['options'],true);
	        	$option_name_array = array();
	        	foreach ($options as $key => $option) 
	        	{
	        		$option_name_array[$key] = $option['name']; 
	        	} 
	        	$brandArray = array_merge_recursive($brandArray, $option_name_array);

	            //$brandArray = array_merge_recursive($brandArray, json_decode($res['options'],true));
	        }
        }
        $input = preg_quote($brandName, '~');
        $result = preg_grep('~' . $input . '~', $brandArray);
        
        if(empty($result))
        	return $brandArray;
        return $result;

    }

    public function fetchVariants($category_id = '', $attribute_id = '', $variant_key = '', $offset = 0)
    {
    	if($category_id)
    	{
    		$url = 'categories/'. $category_id . '/variants';
			$params = array(
				'site_id' => $this->config->get('ced_onbuy_site_id'),
				'limit'  => '10',
				'offset' => $offset,
				);

			$this->load->library('cedonbuy');
			$cedonbuy = Cedonbuy::getInstance($this->registry);
			$access_token = $this->config->get('ced_onbuy_access_token');
	        $access_token_expiry = $this->config->get('ced_onbuy_expires_at');
	        $now = strtotime(date('Y-m-d h:i:s a'));
	        
	        if(!empty($access_token) && !empty($access_token_expiry) && $access_token_expiry > $now)
	        {
	        	$cedonbuy->updateAccessToken();
	        }
			$response = $cedonbuy->getRequest($url, $params);

			if (isset($response['status']) && $response['status'] == true) 
			{
				$response = $response['response'];
				$total_rows = count($response['results']);
				$this->addVariants($category_id, $response['results'], $variant_key);
				$results = $this->db->query("SELECT * FROM `".DB_PREFIX."cedonbuy_variants` WHERE category_id='".$category_id."' AND feature_id = '". $attribute_id . "' ");
				if($total_rows >= '10')
				{
					$noOfVariantsToSkip = $offset + '10';
	            	$this->fetchVariants($noOfVariantsToSkip);
				}
				return $results;
			} else {
				return array();
			}
    	} else {
    		return array();
    	}
    }

    public function addVariants($category_id, $variants_data, $variant_key)
    {
    	if($category_id && is_array($variants_data) && $variants_data)
    	{
    		$this->db->query("DELETE FROM " . DB_PREFIX . "cedonbuy_variants WHERE category_id = '" . (int)$category_id . "'");
    		foreach($variants_data as $key => $variants)
    		{
    			$this->db->query("INSERT INTO `". DB_PREFIX ."cedonbuy_variants` SET feature_id = '". (int) $variants['feature_id'] ."', name = '". strip_tags(html_entity_decode($this->db->escape($variants['name']), ENT_QUOTES, 'UTF-8')) ."', options = '". $this->db->escape(json_encode($variants['options'])) ."', category_id = '". (int) $category_id ."', `variant_key` = '". $this->db->escape($variant_key) ."' ");
    		}
    	}
    }

    public function getStoreOptions($catId, $attribute_id, $brandName)
    {
        $option_value_data = array();
       	$option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_value ov LEFT JOIN " . DB_PREFIX . "option_value_description ovd ON (ov.option_value_id = ovd.option_value_id) WHERE ov.option_id = '" . (int)$attribute_id . "' AND ovd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND ovd.name LIKE '%".$brandName."%' ORDER BY ov.sort_order ASC");
				
		foreach ($option_value_query->rows as $option_value) {
			$option_value_data[] = array(
				'option_value_id' => $option_value['option_value_id'],
				'name'            => $option_value['name'],
				'image'           => $option_value['image'],
				'sort_order'      => $option_value['sort_order']
			);
		}
		return $option_value_data;
    }

	public function getStoreOption()
	{
		$sql = "SELECT * FROM `" . DB_PREFIX . "option` o LEFT JOIN " . DB_PREFIX . "option_description od ON (o.option_id = od.option_id) WHERE od.language_id = '" . (int)$this->config->get('config_language_id') . "' AND `type` IN ('checkbox','select','radio') ORDER BY od.name";
		$result = $this->db->query($sql);
		$options = $result->rows;
		$option_value_data = array();
		if (!empty($options)) {
			foreach ($options as $option) {
				$option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_value ov LEFT JOIN " . DB_PREFIX . "option_value_description ovd ON (ov.option_value_id = ovd.option_value_id) WHERE ov.option_id = '" . (int)$option['option_id'] . "' AND ovd.language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY ov.sort_order ASC");
				foreach ($option_value_query->rows as $option_value) {
					$option_value_data[$option['option_id']][] = array(
						'option_value_id' => $option_value['option_value_id'],
						'name' => $option_value['name'],
					);
				}
			}
			return array('options' => $options, 'option_values' => $option_value_data);
		}
		return array('options' => $options, 'option_values' => $option_value_data);
	}
	
}
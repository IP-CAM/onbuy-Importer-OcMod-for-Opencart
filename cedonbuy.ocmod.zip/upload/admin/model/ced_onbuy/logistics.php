<?php 
class ModelCedOnbuyLogistics extends Model {
	public function addLogistic($data) 
	{
		//echo '<pre>'; print_r($data); die;
		$this->db->query("DELETE FROM " . DB_PREFIX . "cedonbuy_logistics");
		foreach ($data as $logistic) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "cedonbuy_logistics SET 
				country_id = '" . (int)$logistic['country_id'] . "',
				country = '" . $this->db->escape($logistic['country']) . "', 
				country_sub_region_id = '" . (int) $logistic['country_sub_region_id'] . "' , 
				country_sub_region = '" . $this->db->escape($logistic['country_sub_region']) . "', 
				delivery_charge_type_id = '" . (int) $logistic['delivery_charge_type_id'] . "', 
				delivery_charge_type = '" . $this->db->escape($logistic['delivery_charge_type']) . "', 
				delivery_type_id = '" . (int)$logistic['delivery_type_id'] . "', 
				delivery_type = '" . $this->db->escape($logistic['delivery_type']) . "',
				delivery_time_id = '" . (int)$logistic['delivery_time_id'] . "',
				min_days = '" . (int)$logistic['min_days'] . "',
				max_days = '" . (int)$logistic['max_days'] . "',
				delivery_time = '" . $this->db->escape($logistic['delivery_time']) . "',
				price = '" . (float)$logistic['price'] . "',
				additional_price = '" . (float)$logistic['additional_price'] . "',
				template_name = '" . $this->db->escape($logistic['template_name']) . "',
				seller_delivery_template_id = '". (int) $logistic['seller_delivery_template_id'] ."',
				is_default_template = '" . (boolean)$logistic['is_default_template'] . "', 
				delivery_tag = '" . $this->db->escape($logistic['delivery_tag']) . "'
				");
		}
	}

	public function editLogistic($logistics_id, $data) {
		$this->db->query("UPDATE " . DB_PREFIX . "cedonbuy_logistics SET delivery_tag = '" . (int)$data['delivery_tag'] . "', logistic_name = '" . $this->db->escape($data['logistic_name']) . "', sizes = '" . $this->db->escape(json_encode($data['sizes'])) . "' , item_max_dimension = '" . $this->db->escape(json_encode($data['item_max_dimension'])) . "', weight_limits = '" . $this->db->escape(json_encode($data['weight_limits'])) . "', fee_type = '" . $this->db->escape($data['fee_type']) . "', enabled = '" . (int)$data['enabled'] . "', has_cod = '" . (int)$data['has_cod'] . "' WHERE id = '" . (int)$logistics_id. "'");
	}

	public function deleteLogistic($delivery_tag) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "cedonbuy_logistics WHERE delivery_tag = '" . (int)$delivery_tag. "'");
	}

	public function getLogistic($delivery_tag) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cedonbuy_logistics WHERE delivery_tag = '" . $this->db->escape($delivery_tag) . "'");

		return $query->row;
	}

	public function getLogistics($data = array()) {
		$sql = "SELECT * FROM " . DB_PREFIX . "cedonbuy_logistics WHERE delivery_tag != ''";

		if (!empty($data['filter_name'])) {
			$sql .= " AND template_name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}

		if (!empty($data['filter_delivery_tag'])) {
			$sql .= " AND delivery_tag = '" . $this->db->escape($data['filter_delivery_tag']) . "'";
		}

		$sort_data = array(
			'template_name',
			'delivery_tag',
			'status'
		);	

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];	
		} else {
			$sql .= " ORDER BY template_name";	
		}	

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}				

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}	

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}	

		$query = $this->db->query($sql);

		return $query->rows;
	}

	public function getTotalLogistics() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "cedonbuy_logistics");

		return $query->row['total'];
	}	
	
}
?>
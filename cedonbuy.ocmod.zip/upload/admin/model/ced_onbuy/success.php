<?php
class ModelCedOnbuySuccess extends Model {

    public function editSetting($code, $key, $value, $store_id = 0){

        $this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '". $value."' WHERE `code` = '". $this->db->escape($code) ."' AND `key` = '". $this->db->escape($key) ."' AND `store_id` = '". (int)$store_id ."' ");
    }
}
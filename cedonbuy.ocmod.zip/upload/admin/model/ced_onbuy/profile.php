<?php
class ModelCedOnbuyProfile extends Model {
	public function addProfile($data) {
//		echo '<pre>'; print_r($data); die;
		if(isset($data['profile_attribute_mapping']) && !empty($data['profile_attribute_mapping']))
			$data['profile_attribute_mapping'] = $data['profile_attribute_mapping'];
		else
			$data['profile_attribute_mapping'] = array();

		if(isset($data['profile_feature_mapping']) && !empty($data['profile_feature_mapping']))
			$data['profile_feature_mapping'] = $data['profile_feature_mapping'];
		else
			$data['profile_feature_mapping'] = array();

		if(isset($data['profile_variant_mapping']) && !empty($data['profile_variant_mapping']))
			$data['profile_variant_mapping'] = $data['profile_variant_mapping'];
		else
			$data['profile_variant_mapping'] = array();

		$this->db->query("INSERT INTO " . DB_PREFIX . "cedonbuy_profile SET 
			title = '" . $data['title'] . "',
		   status = '" .(int)$data['status']  . "',
		  product_manufacturer = '" . $this->db->escape(json_encode($data['product_manufacturer'])) . "',
		   store_category = '" . $this->db->escape(json_encode($data['product_category'])) . "',
		   profile_store = '" . $this->db->escape(json_encode($data['profile_store'])) . "',
		   profile_language = '" . $this->db->escape($data['profile_language']) . "',
		   attributes = '" . $this->db->escape(json_encode($data['attribute'])) . "',
			onbuy_category = '" . $this->db->escape($data['onbuy_category_id']) . "',  
			onbuy_category_name = '" . $this->db->escape($data['onbuy_category']) . "',
			onbuy_categories = '" . $this->db->escape(json_encode($data['onbuy_category_id'])) . "',
			profile_attribute_mapping = '" . $this->db->escape(json_encode($data['profile_attribute_mapping'])) . "',
			profile_feature_mapping = '". $this->db->escape(json_encode($data['profile_feature_mapping'])) ."',
			profile_variant_mapping = '". $this->db->escape(json_encode($data['profile_variant_mapping'])) ."',
			default_mapping = '" . $this->db->escape(json_encode($data['default_attributes'])) . "'
			");
		$profile_id = $this->db->getLastId();
		if($profile_id){
			$this->removeProductFromProfile($profile_id);
			$this->addProductInProfile($profile_id, $data['product_category'], $data['profile_store'], $data['product_manufacturer']);
		}

		$this->cache->delete('profile');
	}

	public function editProfile($profile_id, $data) {
		//echo '<pre>'; print_r($data); die;
		if(isset($data['profile_attribute_mapping']) && !empty($data['profile_attribute_mapping']))
			$data['profile_attribute_mapping'] = $data['profile_attribute_mapping'];
		else
			$data['profile_attribute_mapping'] = array();

		if(isset($data['profile_feature_mapping']) && !empty($data['profile_feature_mapping']))
			$data['profile_feature_mapping'] = $data['profile_feature_mapping'];
		else
			$data['profile_feature_mapping'] = array();

		if(isset($data['profile_variant_mapping']) && !empty($data['profile_variant_mapping']))
			$data['profile_variant_mapping'] = $data['profile_variant_mapping'];
		else
			$data['profile_variant_mapping'] = array();

		$this->db->query("UPDATE " . DB_PREFIX . "cedonbuy_profile SET title = '" . $data['title'] . "',
		 status = '" .(int)$data['status']  . "',
		  product_manufacturer = '" . $this->db->escape(json_encode($data['product_manufacturer'])) . "',
		   store_category = '" . $this->db->escape(json_encode($data['product_category'])) . "',
		   profile_store = '" . $this->db->escape(json_encode($data['profile_store'])) . "',
		   profile_language = '" . $this->db->escape($data['profile_language']) . "',
		   attributes = '" . $this->db->escape(json_encode($data['attribute'])) . "',
			onbuy_category = '" . $this->db->escape($data['onbuy_category_id']) . "',  
			onbuy_category_name = '" . $this->db->escape($data['onbuy_category']) . "',
			onbuy_categories = '" . $this->db->escape(json_encode($data['onbuy_category_id'])) . "',
			profile_attribute_mapping = '" . $this->db->escape(json_encode($data['profile_attribute_mapping'])) . "',
			profile_feature_mapping = '". $this->db->escape(json_encode($data['profile_feature_mapping'])) ."',
			profile_variant_mapping = '". $this->db->escape(json_encode($data['profile_variant_mapping'])) ."',
			default_mapping = '" . $this->db->escape(json_encode($data['default_attributes'])) . "'
			WHERE id = '" . (int)$profile_id . "'
		");

		//$this->removeProductFromProfile($profile_id);
		$this->updateProductInProfile($profile_id, $data['product_category'], $data['profile_store'], $data['product_manufacturer']);
		$this->cache->delete('profile');
	}

	public function removeProductFromProfile($profile_id)
	{
		$this->db->query("DELETE FROM `".DB_PREFIX."cedonbuy_profile_products` WHERE `profile_id` = '". $profile_id ."' ");
	}

	public function addProductInProfile($profile_id, $categories, $store, $manufacturer)
	{
		$sql = "SELECT DISTINCT (p.product_id) FROM `".DB_PREFIX."product` p LEFT JOIN `".DB_PREFIX."product_to_store` pts on (pts.product_id = p.product_id) LEFT JOIN `".DB_PREFIX."product_to_category` ptc on (ptc.product_id = p.product_id) WHERE p.quantity >0 ";

		if(!empty($categories)){
			$sql .= "AND ptc.category_id IN(".implode(',', $categories).") ";
		}

		if(!empty($store)){
			$sql .= "AND pts.store_id IN(".implode(',', $store).") ";
		}

		if(!empty($manufacturer)){
			$sql .= "AND p.manufacturer_id IN(".implode(',', $manufacturer).") ";
		}

		$result = $this->db->query($sql);

		if($result && $result->num_rows) {
			$products =  array_chunk( $result->rows, 1000);
			foreach ($products as $key => $value) {
				foreach ($result->rows as $key => $product)
				{
					$sql = $this->db->query("SELECT * FROM `".DB_PREFIX."cedonbuy_profile_products` WHERE `product_id` = '". $product['product_id'] ."' ");
					if($sql->num_rows == 0)
					{
						$this->db->query("INSERT INTO `".DB_PREFIX."cedonbuy_profile_products` (`product_id`,`profile_id`) VALUES ('".$product['product_id']."','".$profile_id."') ");
					}
				}
			}
		}
	}

	public function updateProductInProfile($profile_id, $categories, $store, $manufacturer)
	{
		$sql = "SELECT DISTINCT (p.product_id) FROM `".DB_PREFIX."product` p LEFT JOIN `".DB_PREFIX."product_to_store` pts on (pts.product_id = p.product_id) LEFT JOIN `".DB_PREFIX."product_to_category` ptc on (ptc.product_id = p.product_id) WHERE p.quantity >0 ";

		if(!empty($categories)){
			$sql .= "AND ptc.category_id IN(".implode(',', $categories).") ";
		}

		if(!empty($store)){
			$sql .= "AND pts.store_id IN(".implode(',', $store).") ";
		}

		if(!empty($manufacturer)){
			$sql .= "AND p.manufacturer_id IN(".implode(',', $manufacturer).") ";
		}

		$result = $this->db->query($sql);
//echo '<pre>'; print_r($result); die;
		if($result && $result->num_rows) {
			$products =  array_chunk( $result->rows, 1000);
			foreach ($products as $key => $value) {
				foreach ($result->rows as $key => $product)
				{
					$sql = $this->db->query("SELECT * FROM `".DB_PREFIX."cedonbuy_profile_products` WHERE `product_id` = '". $product['product_id'] ."' ");
					if($sql->num_rows == 0)
					{
						$this->db->query("INSERT INTO `".DB_PREFIX."cedonbuy_profile_products` SET `product_id` = '". $product['product_id'] ."' ,`profile_id` = '". $profile_id ."' ");
					}
				}
			}
		}
	}

	public function deleteProfile($profile_id) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "cedonbuy_profile WHERE id = '" . (int)$profile_id . "'");
		$this->removeProductFromProfile($profile_id);
		$this->cache->delete('profile');
	}

	public function getProfile($profile_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "cedonbuy_profile WHERE id = '" . (int)$profile_id . "'");

		return $query->row;
	}

	public function getProfiles($data = array()) {

		$sql = "SELECT * FROM " . DB_PREFIX . "cedonbuy_profile cp WHERE id >= '0'";

		$sort_data = array(
			'title',
			'status',
			'id'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY cp.title";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;

	}

	public function getTotalProfiles() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "cedonbuy_profile");

		return $query->row['total'];
	}

	public function getAttributesMapping()
	{
		return array(
			'product_id' 	=> 'Product ID',
			'name'          => 'Name',
			'description' 	=> 'Description',
			'price' 		=> 'Price',
			'ean'			=> 'EAN',
			'sku' 		    => 'SKU',
			'mpn'			=> 'MPN',
			'upc'			=> 'UPC',
			'isbn' 			=> 'ISBN',
			'model'			=> 'Model',
			'manufacturer_id' => 'Manufacturer'
		);
	}

	public function getMappedAttributes($profile_id) {
		$query = $this->db->query("SELECT `profile_attribute_mapping` FROM " . DB_PREFIX . "cedonbuy_profile WHERE id = '" . (int)$profile_id . "'");
		if($query->num_rows){
			return json_decode($query->row['profile_attribute_mapping'], true);
		}
	}

	public function getMappedFeatures($profile_id) {
		$query = $this->db->query("SELECT `profile_feature_mapping` FROM " . DB_PREFIX . "cedonbuy_profile WHERE id = '" . (int)$profile_id . "'");
		if($query->num_rows){
			return json_decode($query->row['profile_feature_mapping'], true);
		}
	}

	public function getMappedVariants($profile_id) {
		$query = $this->db->query("SELECT `profile_variant_mapping` FROM " . DB_PREFIX . "cedonbuy_profile WHERE id = '" . (int)$profile_id . "'");
		if($query->num_rows){
			return json_decode($query->row['profile_variant_mapping'], true);
		}
	}

	public function getOnbuyBrands($data = array())
	{
		$sql = "SELECT * FROM `". DB_PREFIX ."cedonbuy_brand` WHERE brand_id > '0' ";

		if (!empty($data['filter_id'])) {
			$sql .= " AND brand_id = '" . (int)$data['filter_id'] . "'";
		}

		if (!empty($data['filter_name'])) {
			$sql .= " AND name LIKE '%" . html_entity_decode($data['filter_name']) . "%'";
		}

		$sql .= " GROUP BY brand_id";

		$sort_data = array(
			'name',
			'brand_id'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY brand_id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	public function addBrands($brands)
	{
		if(isset($brands) && is_array($brands) && $brands)
		{
			foreach($brands as $key => $brand)
			{
				$insert = $this->db->query("INSERT INTO `". DB_PREFIX ."cedonbuy_brand` SET 
					`brand_id` = '". (int) $brand['brand_id'] ."', 
					`name`     = '". $this->db->escape(html_entity_decode($brand['name'])) ."',
					`brand_type_id` = '". (int) $brand['brand_type_id'] ."',
					`type`     = '". $this->db->escape(html_entity_decode($brand['type'])) ."'
				");
			}
		}
	}

	public function getConditions($offset = 0)
	{
		$conditionsExist = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedonbuy_conditions` ");
		if($conditionsExist->num_rows)
		{
			return $conditionsExist->rows;
		} else {
			$cedonbuy = Cedonbuy::getInstance($this->registry);
			$url = 'conditions';
			$params = array(
				'site_id' => $this->config->get('ced_onbuy_site_id'),
				'limit' => '10',
				'offset' => $offset
			);
			$access_token = $this->config->get('ced_onbuy_access_token');
			$access_token_expiry = $this->config->get('ced_onbuy_expires_at');
			$now = strtotime(date('Y-m-d h:i:s a'));

			if(!empty($access_token) && !empty($access_token_expiry))
			{
				$cedonbuy->updateAccessToken();
			}
			$response = $cedonbuy->getRequest($url, $params);

			if(isset($response['status']) && $response['status'] == true)
			{
				$response = $response['response'];
				$total_rows = $response['results'];
				$this->addConditions($response['results']);
				if($total_rows >= '10')
				{
					$noOfConditionsToSkip = $offset + '10';
					$this->getConditions($noOfConditionsToSkip);
				}
				return $response['results'];
			} else {
				return array();
			}
		}
	}

	public function addConditions($condition_array)
	{
		if(isset($condition_array) && $condition_array)
		{
			foreach($condition_array as $key => $condition)
			{
				$this->db->query("INSERT INTO `". DB_PREFIX ."cedonbuy_conditions` SET 
					`condition_id` = '". (int) $condition['condition_id'] ."',
					`name` = '". $this->db->escape($condition['name']) ."',
					`code` = '". $this->db->escape($condition['code']) ."'
				");
			}
		}
	}
}
?>

<?php
// Heading
$_['heading_title']                 = 'OnBuy Integration By Cedcommerce';

// Text
$_['text_module']                   = 'Modules';
$_['text_success']                  = 'Success: You have modified CED onbuy module!';
$_['text_edit']                     = 'Edit OnBuy Configuration';

//Tabs
$_['tab_general']                    = 'General';
$_['tab_onbuy_product']              = 'Product Setting';
$_['tab_onbuy_order']                = 'Order Setting';
$_['tab_onbuy_cron']                 = 'Cron Setting';
// $_['tab_onbuy_chunk']                = 'Chunk (Batch) Setting';

// General Tab
$_['entry_status']                   = 'Status';
$_['entry_api_url']                  = 'API Url';
$_['entry_secret_key'] 			     = 'Secret Key';
$_['entry_consumer_key'] 			 = 'Consumer Key';
$_['entry_site_id'] 				 = 'Site ID';
$_['entry_seller_id'] 				 = 'Seller ID';
$_['entry_seller_entity_id'] 	     = 'Seller Entity ID';
$_['button_generate']                = 'Get Access Token'; 
$_['entry_access_token']             = 'Access Token';
$_['entry_enable_logging']           = 'Enable Onbuy Log';
$_['entry_store_language']           = 'Store Language';

// onbuy Product Settings Tab
$_['entry_product_price']            = 'Product Price';
$_['entry_product_price_fixed']      = 'Modify By Fixed Price';
$_['entry_product_price_percentage'] = 'Modify By Percentage';
$_['entry_auto_update_product']      = 'Auto Update Product';

// onbuy Order Settings Tab
// $_['entry_order_id_prefix']          = 'Order ID Prefix';
// $_['entry_order_notification']       = 'Allow Order Notification';
$_['entry_order_noti_email']         = 'Order Notification Email';
$_['entry_default_customer_email']   = 'Default Customer Email';
$_['entry_accept_order']             = 'Auto Accept Order';
$_['entry_cancel_order']             = 'Auto Cancel Order';
$_['entry_order_status']            = 'Order Status';
$_['entry_order_status_importing']  = 'Order status while importing order';
$_['entry_order_accepted']          = 'Order Accepted';
$_['entry_order_after_accepted']    = 'Order status after accepted order';
$_['entry_order_rejected']          = 'Order Rejected';
$_['entry_order_after_rejected']    = 'Order status after rejected order';
$_['entry_order_shipped']           = 'Order Shipped';
$_['entry_order_after_shipped']     = 'Order status after shipped order';
$_['entry_order_carrier']           = 'Order Carrier';
$_['entry_order_carrier_importing'] = 'Order carrier while importing order';
$_['entry_order_payment']           = 'Payment Method';
$_['entry_order_payment_importing'] = 'Order payment while importing order';

// onbuy Cron Settings Tab
$_['entry_order_cron']               = 'Order Cron';
$_['entry_order_cron_time']          = 'Order Cron Time';
$_['entry_inventory_cron']           = 'Inventory & Price Cron';
$_['entry_inventory_cron_time']      = 'Inventory Cron Time';
$_['entry_product_sync_cron']           = 'Product Sync Cron';
$_['entry_product_sync_cron_time']      = 'Product Sync Cron Time';
$_['entry_product_upload_cron']           = 'Product Upload Cron';
$_['entry_product_upload_cron_time']      = 'Product Upload Cron Time';

$_['ced_onbuy_order_cron']               = HTTPS_CATALOG . 'index.php?route=ced_onbuy/order/fetchOrder';;
$_['ced_onbuy_order_cron_time']          = '30 mins';
$_['ced_onbuy_inventory_cron']           = HTTPS_CATALOG . 'index.php?route=ced_onbuy/product/updateStock';
$_['ced_onbuy_inventory_cron_time']      = 'Once a day';
$_['ced_onbuy_product_sync_cron']           = HTTPS_CATALOG . 'index.php?route=ced_onbuy/product/syncStatus';
$_['ced_onbuy_product_sync_cron_time']      = 'Once a day';
$_['ced_onbuy_product_upload_cron']           = HTTPS_CATALOG . 'index.php?route=ced_onbuy/product/uploadAllProducts';
$_['ced_onbuy_product_upload_cron_time']      = 'Once a day';


// Error
$_['error_permission']               = 'Warning: You do not have permission to modify Ced OnBuy module!';
$_['error_code']                     = 'Please Fill Client ID and Client Secret';
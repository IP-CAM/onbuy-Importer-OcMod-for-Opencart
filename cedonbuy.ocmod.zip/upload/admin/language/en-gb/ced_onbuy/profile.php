<?php
// Heading
$_['heading_title']     = 'Cedonbuy Profile';

// Text
$_['text_success']      = 'Success: You have modified Profile!';
$_['text_default']      = 'Default';
$_['text_list']         = 'Profile List';
$_['text_add']          = 'Add Profile';
$_['text_edit']         = 'Edit Profile';

//Tab 
$_['tab_attribute']     = 'Attribute Mapping';
$_['tab_onbuy_category']= 'Onbuy Category & Attributes';
$_['tab_default_attributes']= 'Default Attribute Mapping';

// Column
$_['column_title']      = 'Title';
$_['column_id']			= 'Profile ID';
$_['column_status']		= 'Status';
$_['column_action']     = 'Action';

// Entry
$_['entry_title']       = 'Title';
$_['entry_manufacturer']= 'Manufacturer';
$_['entry_store']       = 'Stores';
$_['entry_category']    = 'Category';
$_['entry_onbuy_category'] = 'Onbuy Category';
$_['entry_status']      = 'Status';

$_['entry_uid'] 		  = 'UID';
$_['entry_category_id']   = 'Category ID';
$_['entry_product_name']  = 'Product Name';
$_['entry_mpn']           = 'MPN';
$_['entry_product_codes'] = 'Product Codes';
$_['entry_description']   = 'Description';
$_['entry_rrp']           = 'Price (RRP)';

$_['entry_published']        = 'Published';
$_['entry_summary_points']   = 'Summary Point';
$_['entry_brand_name']       = 'Brand Name';
$_['entry_brand_id']         = 'Brand ID';
$_['entry_condition']        = 'Condition';
$_['entry_delivery'] 		 = 'Delivery';

$_['entry_onbuy_attribute'] = 'Onbuy Attribute(s)';
$_['entry_store_attribute']  = 'Store Attribute(s)';
$_['entry_language']        = 'Language';
// Error 
$_['error_warning']     = 'Warning: Please check the form carefully for errors!';
$_['error_permission']  = 'Warning: You do not have permission to modify information!';
$_['error_title']       = 'Information Title must be between 3 and 64 characters!';
$_['error_description'] = 'Description must be more than 3 characters!';
$_['error_account']     = 'Warning: This information page cannot be deleted as it is currently assigned as the store account terms!';
$_['error_checkout']    = 'Warning: This information page cannot be deleted as it is currently assigned as the store checkout terms!';
$_['error_affiliate']   = 'Warning: This information page cannot be deleted as it is currently assigned as the store affiliate terms!';
$_['error_store']       = 'Warning: This information page cannot be deleted as its currently used by %s stores!';

// Button
$_['button_insert'] = 'Add Profile';
$_['button_edit'] = 'Edit Profile';
?>
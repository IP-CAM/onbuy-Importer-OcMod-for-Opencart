<?php
// Heading
$_['heading_title']          = 'Onbuy Delivery';

// Text
$_['text_success']           = 'Success: You have modified Ced Onbuy category!';
$_['text_list']              = 'Onbuy Delivery List';
$_['text_view']              = 'Onbuy Delivery View';
$_['text_ced_onbuy']         = 'Ced Onbuy';

// Column
$_['column_name']            = 'Template Name';
$_['column_delivery_tag']    = 'Delivery Tag';
$_['column_action']          = 'Action';

// Entry
$_['entry_id']               = 'Delivery ID';
$_['entry_name']             = 'Delivery Name';

// Error
$_['error_warning']          = 'Warning: Please check the form carefully for errors!';
$_['error_permission']       = 'Warning: You do not have permission to modify Ced Onbuy categories!';
$_['error_name']             = 'Delivery Name must be between 2 and 32 characters!';

//Filter Button
$_['button_filter']          = 'Filter';

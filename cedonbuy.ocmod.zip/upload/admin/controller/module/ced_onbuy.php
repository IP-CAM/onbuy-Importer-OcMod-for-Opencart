<?php

class ControllerModuleCedOnbuy extends Controller
{
    private $error = array();

    public function index(){

        $this->load->language('module/ced_onbuy');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if(($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()){
            $this->model_setting_setting->editSetting('ced_onbuy', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
        }

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_edit']      = $this->language->get('text_edit');
        $data['text_enabled']   = $this->language->get('text_enabled');
        $data['text_disabled']  = $this->language->get('text_disabled');

        // Tabs
        $data['tab_general']      = $this->language->get('tab_general');
        $data['tab_onbuy_product'] = $this->language->get('tab_onbuy_product');
        $data['tab_onbuy_order']  = $this->language->get('tab_onbuy_order');
        $data['tab_onbuy_cron']   = $this->language->get('tab_onbuy_cron');
        // $data['tab_onbuy_chunk']  = $this->language->get('tab_onbuy_chunk');

        // General Tab
        $general_tabs = array('status', 'api_url', 'secret_key', 'consumer_key', 'site_id', 'seller_id', 'seller_entity_id', 'access_token', 'expires_at', 'enable_logging', 'store_language');

        foreach ($general_tabs as $general_tab) 
         {
           $data['entry_' . $general_tab] = $this->language->get('entry_' . $general_tab);  
         }
        
         $data['button_generate']       = $this->language->get('button_generate');
         

        // onbuy Product Settings Tab
        $product_tabs = array('product_price', 'product_price_fixed', 'product_price_percentage', 'auto_update_product');
         
        foreach ($product_tabs as $product_tab) 
        {
          $data['entry_' . $product_tab] = $this->language->get('entry_' . $product_tab);
        }

        // onbuy Order Settings Tab
        $order_tabs = array('order_noti_email', 'default_customer_email', 'cancel_order', 'accept_order', 'order_status', 'order_status_importing', 'order_accepted', 'order_after_rejected', 'order_after_accepted', 'order_after_shipped', 'order_carrier_importing', 'order_payment_importing', 'order_rejected', 'order_shipped', 'order_carrier', 'order_payment');

        foreach ($order_tabs as $order_tab) 
        {
          $data['entry_' . $order_tab] = $this->language->get('entry_' . $order_tab);
        }

        // onbuy Cron Settings Tab
        $cron_tabs = array('order_cron', 'order_cron_time', 'inventory_cron', 'inventory_cron_time', 'product_sync_cron', 'product_sync_cron_time', 'product_upload_cron', 'product_upload_cron_time');

        foreach ($cron_tabs as $cron_tab) 
        {
          $data['entry_' . $cron_tab] = $this->language->get('entry_' . $cron_tab);
          $data['ced_onbuy_' . $cron_tab] = $this->language->get('ced_onbuy_' . $cron_tab);
        }

        $data['button_save']    = $this->language->get('button_save');
        $data['button_cancel']  = $this->language->get('button_cancel');

        $this->load->model('localisation/order_status');

        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        $this->load->model('localisation/language');
        $data['languages'] = $this->model_localisation_language->getLanguages();
        
        $this->load->library('cedonbuy');
        $cedonbuy = Cedonbuy::getInstance($this->registry);

        $data['order_ship'] = $cedonbuy->getExtensions('shipping');

        $data['order_carriers'] = $cedonbuy->getExtensions('shipping');

        $data['order_pay'] = $cedonbuy->getExtensions('payment');

        if(isset($this->error['warning'])){
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if(isset($this->error['code'])){
            $data['error_code'] = $this->error['code'];
        } else {
            $data['error_code'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_module'),
            'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('module/ced_onbuy', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['action'] = $this->url->link('module/ced_onbuy', 'token=' . $this->session->data['token'], 'SSL');

        $data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

         $data['token'] = $this->session->data['token'];

         $this->load->model('localisation/language');

         $data['languages'] = $this->model_localisation_language->getLanguages();

        // General Tab
        foreach ($general_tabs as $general_tab) {
            if (isset($this->request->post['ced_onbuy_' . $general_tab])) {
                $data['ced_onbuy_' . $general_tab] = $this->request->post['ced_onbuy_' . $general_tab];
            } else {
                $data['ced_onbuy_' . $general_tab] = $this->config->get('ced_onbuy_' . $general_tab);
            }
        }

        $data['ced_onbuy_api_url'] = 'https://api.onbuy.com/v2/';
        
        // onbuy Product Settings
        foreach ($product_tabs as $product_tab) {
            if (isset($this->request->post['ced_onbuy_' . $product_tab])) {
                $data['ced_onbuy_' . $product_tab] = $this->request->post['ced_onbuy_' . $product_tab];
            } else {
                $data['ced_onbuy_' . $product_tab] = $this->config->get('ced_onbuy_' . $product_tab);
            }
        }

        // onbuy Order Settings
        foreach ($order_tabs as $order_tab) {
            if (isset($this->request->post['ced_onbuy_' . $order_tab])) {
                $data['ced_onbuy_' . $order_tab] = $this->request->post['ced_onbuy_' . $order_tab];
            } else {
                $data['ced_onbuy_' . $order_tab] = $this->config->get('ced_onbuy_' . $order_tab);
            }
        }

        // onbuy Cron Settings
        // foreach ($cron_tabs as $cron_tab) {
        //     if (isset($this->request->post['ced_onbuy_' . $cron_tab])) {
        //         $data['ced_onbuy_' . $cron_tab] = $this->request->post['ced_onbuy_' . $cron_tab];
        //     } else {
        //         $data['ced_onbuy_' . $cron_tab] = $this->config->get('ced_onbuy_' . $cron_tab);
        //     }
        // }

        $data['header']  = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('module/ced_onbuy.tpl', $data));

    }

    protected function validate(){
        if(!$this->user->hasPermission('modify', 'module/ced_onbuy')){
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }

    public function install()
    {
        $this->load->model('user/user_group');
       
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_onbuy/category');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_onbuy/category');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_onbuy/profile');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_onbuy/profile');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_onbuy/product');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_onbuy/product');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_onbuy/order');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_onbuy/order');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_onbuy/order_error');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_onbuy/order_error');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_onbuy/logistics');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_onbuy/logistics');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'module/ced_onbuy');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'module/ced_onbuy');

        $this->load->library('cedonbuy');
        $cedonbuy = Cedonbuy::getInstance($this->registry);

        if (!$cedonbuy->isCedOnbuyInstalled())
        {
            $cedonbuy->installCedOnbuy();
        }

        $shop_email =  $this->config->get('config_email');
        $shop_url = HTTPS_CATALOG;

        $require_data =  array('domain'=>$shop_url, 'email'=>$shop_email, 'framework'=>'Opencart');
        $cedcommerce_url = 'http://admin.apps.cedcommerce.com/magento-onbuy-info/create&domain=<?php echo $shop_url; ?>&email=<?php echo $shop_email; ?>&framework=Opencart';

        $ch = curl_init($cedcommerce_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);

        // Check if any error occurred
        if (curl_errno($ch)) {
            $cedonbuy->log(
                METHOD,
                'Warning',
                'Install Message curl error',
                curl_errno($ch)
            );
        }

        // Close handle
        curl_close($ch);

        $this->load->model('extension/event');

        $this->model_extension_event->addEvent('ced_onbuy', 'post.admin.product.add', 'ced_onbuy/product/addNewProductsToVariants');
    }

    public function uninstall()
    {
        // $this->load->model('module/cedonbuy_category');

        $this->load->model('user/user_group');

        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_onbuy/category');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_onbuy/category');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_onbuy/profile');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_onbuy/profile');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_onbuy/product');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_onbuy/product');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_onbuy/order');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_onbuy/order');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_onbuy/order_error');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_onbuy/order_error');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_onbuy/logistics');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_onbuy/logistics');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'module/ced_onbuy');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'module/ced_onbuy');

        $this->load->model('extension/event');

        $this->model_extension_event->deleteEvent('ced_onbuy');
    }

    public function getAccessToken()
    {
        $this->load->library('cedonbuy');
        $url = 'auth/request-token';
        $params = $this->request->post;
        $cedonbuy = Cedonbuy::getInstance($this->registry);
        //echo '<pre>'; print_r($params); die;
        $auth = $cedonbuy->postRequest($url, $params);

        $response = array();
        if(isset($auth['status']) && $auth['status'] == true)
        {
            $access_token = $auth['response']['access_token'];
            $expires_at = $auth['response']['expires_at'];
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSettingValue('ced_onbuy', 'ced_onbuy_access_token' , $access_token);
            $this->model_setting_setting->editSettingValue('ced_onbuy', 'ced_onbuy_expires_at' , $expires_at);
            
            $response['success'] = true;
            $response['message'] = 'Access Token Fetched Successfully. Please once refresh this page & Save the settings.';
        } else {
            $response['success'] = false;
            $response['message'] = !empty($auth['response']) ? $auth['response']:'Invalid Credentials';
        }
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($response));
    }
}


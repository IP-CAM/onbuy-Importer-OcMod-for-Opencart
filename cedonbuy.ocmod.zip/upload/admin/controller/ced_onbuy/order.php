<?php
class ControllerCedOnbuyOrder extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('ced_onbuy/order');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('ced_onbuy/order');
		$this->getList();
	}
	public function fetchOrder() {

		$this->load->library('cedonbuy');
		$this->load->language('ced_onbuy/order');
		$this->load->model('ced_onbuy/order');
		$cedonbuy = Cedonbuy::getInstance($this->registry); 
        
		$response = $cedonbuy->fetchOrders();

		if(isset($response['success']) && $response['success']) {
			if(count($response['message']))
			$this->session->data['success'] = isset($response['message']) ? $response['message'] : 'Order Imported Successfully.';
			else 
			$this->session->data['success'] = isset($response['message']) ? $response['message'] : 'No new Orders Found.';
		} else {
			$this->error[] = $response['message'];
		}
		$this->getList();
	}
	
	public function delete() {
		$this->load->language('ced_onbuy/order');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_onbuy/order');

		if (isset($this->request->post['selected']) && $this->validate()) {
			foreach ($this->request->post['selected'] as $order_id) {
				$this->model_ced_onbuy_order->deleteOrder($order_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_order_id'])) {
				$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
			}
	
			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}
	
			if (isset($this->request->get['filter_order_status'])) {
				$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
			} 

			if (isset($this->request->get['filter_onbuy_order_status'])) {
				$url .= '&filter_onbuy_order_status=' . $this->request->get['filter_onbuy_order_status'];
			}
	
			if (isset($this->request->get['filter_total'])) {
				$url .= '&filter_total=' . $this->request->get['filter_total'];
			}
	
			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}
	
			$this->response->redirect($this->url->link('ced_onbuy/order', 'token=' . $this->session->data['token'] . $url, true));
		}

		$this->getList();
	}
	
	protected function getList() {
		
		if (isset($this->request->get['filter_order_id'])) {
			$filter_order_id = $this->request->get['filter_order_id'];
		} else {
			$filter_order_id = null;
		}

		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = null;
		}

		if (isset($this->request->get['filter_order_status'])) {
			$filter_order_status = $this->request->get['filter_order_status'];
		} else {
			$filter_order_status = null;
		} 

		if (isset($this->request->get['filter_onbuy_order_status'])) {
			$filter_onbuy_order_status = $this->request->get['filter_onbuy_order_status'];
		} else {
			$filter_onbuy_order_status = null;
		}

		if (isset($this->request->get['filter_total'])) {
			$filter_total = $this->request->get['filter_total'];
		} else {
			$filter_total = null;
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = null;
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'o.order_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_order_status'])) {
			$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
		} 

		if (isset($this->request->get['filter_onbuy_order_status'])) {
			$url .= '&filter_onbuy_order_status=' . $this->request->get['filter_onbuy_order_status'];
		}

		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_ced_onbuy'),
			'href' => $this->url->link('ced_onbuy/map_category', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('ced_onbuy/order', 'token=' . $this->session->data['token'] . $url, true)
		);

		$data['fetchOrder'] = $this->url->link('ced_onbuy/order/fetchOrder', 'token=' . $this->session->data['token'], true);
		$data['delete'] = $this->url->link('ced_onbuy/order/delete', 'token=' . $this->session->data['token'], true);

		$data['orders'] = array();

		$filter_data = array(
			'filter_order_id'      => $filter_order_id,
			'filter_customer'	   => $filter_customer,
			'filter_order_status'  => $filter_order_status,
			'filter_onbuy_order_status' => $filter_onbuy_order_status,
			'filter_total'         => $filter_total,
			'filter_date_added'    => $filter_date_added,
			'sort'                 => $sort,
			'order'                => $order,
			'start'                => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                => $this->config->get('config_limit_admin')
		);

		$order_total = $this->model_ced_onbuy_order->getTotalOrders($filter_data);

		$results = $this->model_ced_onbuy_order->getOrders($filter_data);
		 //echo '<pre>'; print_r($order_total); die();

		foreach ($results as $result) {
			$data['orders'][] = array(
				'order_id'      => $result['order_id'],
				'customer'      => $result['customer'],
				'order_status'  => $result['order_status'] ? $result['order_status'] : $this->language->get('text_missing'),
				'total'         => $this->currency->format($result['total'], $result['currency_code'], $result['currency_value']),
				'date_added'    => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'onbuy_order_id' => $result['onbuy_order_id'],
				'onbuy_status' => $result['onbuy_status'],
				'shipping_code' => $result['shipping_code'],
				'view'          => $this->url->link('ced_onbuy/order/info', 'token=' . $this->session->data['token'] . '&order_id=' . $result['order_id'] . $url, true)
			);
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_list'] = $this->language->get('text_list');
		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_confirm'] = $this->language->get('text_confirm');
		$data['text_missing'] = $this->language->get('text_missing');
		$data['text_loading'] = $this->language->get('text_loading');

		$data['column_order_id'] = $this->language->get('column_order_id');
		$data['column_customer'] = $this->language->get('column_customer');
		$data['column_status'] = $this->language->get('column_status');
		$data['column_total'] = $this->language->get('column_total');
		$data['column_onbuy_order_id'] = $this->language->get('column_onbuy_order_id');
		$data['column_onbuy_status'] = $this->language->get('column_onbuy_status');
		$data['column_date_added'] = $this->language->get('column_date_added');
		$data['column_action'] = $this->language->get('column_action');

		$data['button_invoice_print'] = $this->language->get('button_invoice_print');
		$data['button_shipping_print'] = $this->language->get('button_shipping_print');
		$data['button_add'] = $this->language->get('button_add');
		$data['button_edit'] = $this->language->get('button_edit');
		$data['button_delete'] = $this->language->get('button_delete');
		$data['button_filter'] = $this->language->get('button_filter');
		$data['button_view'] = $this->language->get('button_view');
		$data['button_ip_add'] = $this->language->get('button_ip_add');

		$data['token'] = $this->session->data['token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_order_status'])) {
			$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
		} 

		if (isset($this->request->get['filter_onbuy_order_status'])) {
			$url .= '&filter_onbuy_order_status=' . $this->request->get['filter_onbuy_order_status'];
		}

		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_order'] = $this->url->link('ced_onbuy/order', 'token=' . $this->session->data['token'] . '&sort=o.order_id' . $url, true);
		$data['sort_customer'] = $this->url->link('ced_onbuy/order', 'token=' . $this->session->data['token'] . '&sort=customer' . $url, true);
		$data['sort_status'] = $this->url->link('ced_onbuy/order', 'token=' . $this->session->data['token'] . '&sort=order_status' . $url, true);
		$data['sort_total'] = $this->url->link('ced_onbuy/order', 'token=' . $this->session->data['token'] . '&sort=o.total' . $url, true);
		$data['sort_onbuy_order'] = $this->url->link('ced_onbuy/order', 'token=' . $this->session->data['token'] . '&sort=so.onbuy_order_id' . $url, true);
		$data['sort_onbuy_status'] = $this->url->link('ced_onbuy/order', 'token=' . $this->session->data['token'] . '&sort=so.onbuy_status' . $url, true);
		$data['sort_date_added'] = $this->url->link('ced_onbuy/order', 'token=' . $this->session->data['token'] . '&sort=o.date_added' . $url, true);
		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_order_status'])) {
			$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
		} 

		if (isset($this->request->get['filter_onbuy_order_status'])) {
			$url .= '&filter_onbuy_order_status=' . $this->request->get['filter_onbuy_order_status'];
		}

		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $order_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('ced_onbuy/order', 'token=' . $this->session->data['token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($order_total - $this->config->get('config_limit_admin'))) ? $order_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $order_total, ceil($order_total / $this->config->get('config_limit_admin')));

		$data['filter_order_id'] = $filter_order_id;
		$data['filter_customer'] = $filter_customer;
		$data['filter_order_status'] = $filter_order_status;
		$data['filter_onbuy_order_status'] = $filter_onbuy_order_status;
		$data['filter_total'] = $filter_total;
		$data['filter_date_added'] = $filter_date_added;

		$data['sort'] = $sort;
		$data['order'] = $order;

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('ced_onbuy/order_list.tpl', $data));
	}

	public function info() {
		$this->load->model('ced_onbuy/order');

		if (isset($this->request->get['order_id'])) {
			$order_id = $this->request->get['order_id'];
		} else {
			$order_id = 0;
		}

		$order_info = $this->model_ced_onbuy_order->getOrder($order_id);

		if ($order_info) {
			$this->load->language('ced_onbuy/order');

			$this->document->setTitle($this->language->get('heading_title'));

			$data['heading_title'] = $this->language->get('heading_title');
			
			$data['text_order_detail'] = $this->language->get('text_order_detail');
			$data['text_order'] = sprintf($this->language->get('text_order'), $this->request->get['order_id']);
			$data['text_shipping_info'] = $this->language->get('text_shipping_info');
            $data['text_products_info'] = $this->language->get('text_products_info');
			$data['text_ship_whole_order'] = $this->language->get('text_ship_whole_order');

			$data['column_sr_no'] = $this->language->get('column_sr_no');
			$data['column_skuId'] = $this->language->get('column_skuId');
			$data['column_onbuyProductId'] = $this->language->get('column_onbuyProductId');
			$data['column_productTitle'] = $this->language->get('column_productTitle');
			$data['column_orderTotal'] = $this->language->get('column_orderTotal');
			$data['column_quantity'] = $this->language->get('column_quantity');
			$data['column_unit_price'] = $this->language->get('column_unit_price');

			$data['column_order_id'] = $this->language->get('column_order_id');
			$data['column_tracking_id'] = $this->language->get('column_tracking_id');
			$data['column_tracking_number'] = $this->language->get('column_tracking_number');
			$data['column_tracking_url'] = $this->language->get('column_tracking_url');

			$data['entry_customer_id'] = $this->language->get('entry_customer_id');
			$data['entry_orderId'] = $this->language->get('entry_orderId');
			$data['entry_order_date'] = $this->language->get('entry_order_date');
			$data['entry_onbuy_status'] = $this->language->get('entry_onbuy_status');
			$data['entry_language_code'] = $this->language->get('entry_language_code');
			$data['entry_shipping_method'] = $this->language->get('entry_shipping_method');
			$data['entry_cost'] = $this->language->get('entry_cost');
			$data['entry_shippingCost'] = $this->language->get('entry_shippingCost');

			$data['entry_shipping_firstname'] = $this->language->get('entry_shipping_firstname');
			$data['entry_shipping_lastname'] = $this->language->get('entry_shipping_lastname');
			$data['entry_shipping_address_1'] = $this->language->get('entry_shipping_address_1');
			$data['entry_shipping_city'] = $this->language->get('entry_shipping_city');
			$data['entry_shipping_postcode'] = $this->language->get('entry_shipping_postcode');
			$data['entry_shipping_iso_code_3'] = $this->language->get('entry_shipping_iso_code_3');
			$data['entry_telephone'] = $this->language->get('entry_telephone');
			
			//$data['button_edit'] = $this->language->get('button_edit');
			$data['button_cancel'] = $this->language->get('button_cancel');

			$url = '';

			if (isset($this->request->get['filter_order_id'])) {
				$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
			}

			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_order_status'])) {
				$url .= '&filter_order_status=' . $this->request->get['filter_order_status'];
			}

			if (isset($this->request->get['filter_onbuy_order_status'])) {
				$url .= '&filter_onbuy_order_status=' . $this->request->get['filter_onbuy_order_status'];
			}

			if (isset($this->request->get['filter_total'])) {
				$url .= '&filter_total=' . $this->request->get['filter_total'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$data['breadcrumbs'] = array();

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
			);

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('ced_onbuy/order', 'token=' . $this->session->data['token'] . $url, true)
			);

			// $data['shipping'] = $this->url->link('ced_onbuy/order/shipping', 'token=' . $this->session->data['token'] . '&order_id=' . (int)$this->request->get['order_id'], true);
			// $data['invoice'] = $this->url->link('ced_onbuy/order/invoice', 'token=' . $this->session->data['token'] . '&order_id=' . (int)$this->request->get['order_id'], true);
			// $data['edit'] = $this->url->link('ced_onbuy/order/edit', 'token=' . $this->session->data['token'] . '&order_id=' . (int)$this->request->get['order_id'], true);
			$data['cancel'] = $this->url->link('ced_onbuy/order', 'token=' . $this->session->data['token'] . $url, true);
			$data['cancelOrder'] = $this->url->link('ced_onbuy/order/cancelOrder', 'token=' . $this->session->data['token'] . $url, true);

			$data['token'] = $this->session->data['token'];
			
			$data['order_id'] = $this->request->get['order_id'];

			$data['customer_id'] = $order_info['customer_id'];
			$data['OrderId']     = $order_info['OrderId'];
			$data['order_date'] = (isset($order_info['order_data']['date']) && !empty($order_info['order_data']['date'])) ? $order_info['order_data']['date'] : $order_info['date_added'];
			$data['onbuy_status'] = $order_info['onbuy_status'];
			$data['language_code'] = $order_info['language_code'];
			$data['shipping_method'] = $order_info['shipping_method'];
			$data['cost'] = $order_info['order_data']['price_total'];
			$data['shippingCost'] = $order_info['order_data']['price_delivery'];

			$data['shipping_firstname'] = $order_info['shipping_firstname'];
			$data['shipping_lastname'] = $order_info['shipping_lastname'];
			$data['shipping_address_1'] = $order_info['shipping_address_1'];
			$data['shipping_city'] = $order_info['shipping_city'];
			$data['shipping_postcode'] = $order_info['shipping_postcode'];
			$data['shipping_iso_code_3'] = $order_info['shipping_iso_code_3'];
			$data['telephone'] = $order_info['telephone'];

			$orderProductData = $order_info['order_data']['products'];

			foreach($orderProductData as $key => $product)
			{
				$data['productInfo'][] = array(
					'skuId' => $product['sku'],
					'onbuyProductId' => $product['opc'],
					'productTitle' => $product['name'],
					'quantity' => $product['quantity'],
					'unitPrice' => $product['unit_price'],
					'productTotal' => $product['total_price']
				);
			}

			$data['store_id'] = $order_info['store_id'];
			$data['store_name'] = $order_info['store_name'];

			$data['tracking_provider'] = $this->model_ced_onbuy_order->getTrackingProvider();

			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');

			$this->response->setOutput($this->load->view('ced_onbuy/order_info.tpl', $data));
		} else {
			return new Action('error/not_found');
		}
	}

	public function cancelOrder(){

		$this->load->library('cedonbuy');
		$cedonbuy = Cedonbuy::getInstance($this->registry);

        $this->load->language('ced_onbuy/order');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('ced_onbuy/order');

		if ($this->request->server['REQUEST_METHOD'] == 'POST') 
		{
            $result = $cedonbuy->cancelOrder($this->request->post);
            //echo '<pre>'; print_r($result); die;
            if(isset($result['success']) && empty($result['message'])) 
            {
             die(json_encode(array('success' => true,'message' => 'Order Cancelled Successfully')));
            }
            $error_res = 'Some Error While Cancelling Order.';
            if(isset($result['message']))
                $error_res = $result['message'];
            die(json_encode(array('success' => false,'message' => $error_res)));
	    }
    }

	public function dispatchOrder()
	{
		$this->load->library('cedonbuy');
		$cedonbuy = Cedonbuy::getInstance($this->registry);

        $this->load->language('ced_onbuy/order');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('ced_onbuy/order');

		if ($this->request->server['REQUEST_METHOD'] == 'POST') 
		{
            $result = $cedonbuy->dispatchOrder($this->request->post);

            if(isset($result['success']) && empty($result['message']))
            {
              die(json_encode(array('success' => true,'message' => 'Order Shipped Successfully')));
            }
            $error_res = 'Some Error While Shipment.';
            if(isset($result['message']))
                $error_res = $result['message'];
            die(json_encode(array('success' => false,'message' => $error_res)));
		}
	}

	public function refundOrder()
	{
		$this->load->library('cedonbuy');
		$cedonbuy = Cedonbuy::getInstance($this->registry);

        $this->load->language('ced_onbuy/order');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('ced_onbuy/order');

		if ($this->request->server['REQUEST_METHOD'] == 'POST') 
		{
            $result = $cedonbuy->refundOrder($this->request->post);

            if(isset($result['success']) && empty($result['message']))
            {
              die(json_encode(array('success' => true,'message' => 'Order Shipped Successfully')));
            }
            $error_res = 'Some Error While Shipment.';
            if(isset($result['message']))
                $error_res = $result['message'];
            die(json_encode(array('success' => false,'message' => $error_res)));
		}
	}
	
	protected function validate() {
		if (!$this->user->hasPermission('modify', 'ced_onbuy/order')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
}
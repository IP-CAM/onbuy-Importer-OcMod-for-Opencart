<?php
class ControllerCedOnbuyProfile extends Controller { 
	private $error = array();

	public function index() {
		$this->language->load('ced_onbuy/profile');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_onbuy/profile');

		$this->getList();
	}

	public function insert() {
		$this->language->load('ced_onbuy/profile');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_onbuy/profile');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_ced_onbuy_profile->addProfile($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('ced_onbuy/profile', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getForm();
	}

	public function update() {
		$this->language->load('ced_onbuy/profile');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_onbuy/profile');
//echo '<pre>'; print_r($this->request->post); die;
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			$this->model_ced_onbuy_profile->editProfile($this->request->get['id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('ced_onbuy/profile', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getForm();
	}

	public function delete() {
		$this->language->load('ced_onbuy/profile');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_onbuy/profile');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $id) {

				$this->model_ced_onbuy_profile->deleteProfile($id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('ced_onbuy/profile', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'title';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('ced_onbuy/profile', 'token=' . $this->session->data['token'] . $url, 'SSL')
		);

		$data['insert'] = $this->url->link('ced_onbuy/profile/insert', 'token=' . $this->session->data['token'] . $url, 'SSL');
		$data['fetchBrand'] = $this->url->link('ced_onbuy/profile/fetchBrand', 'token=' . $this->session->data['token'] . $url, 'SSL');
		$data['delete'] = $this->url->link('ced_onbuy/profile/delete', 'token=' . $this->session->data['token'] . $url, 'SSL');	

		$data['profiles'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$profile_total = $this->model_ced_onbuy_profile->getTotalProfiles($filter_data);

		$results = $this->model_ced_onbuy_profile->getProfiles($filter_data);

		foreach ($results as $result) {
			$action = array();

			$action[] = array(
				'text' => $this->language->get('text_edit'),
				'href' => $this->url->link('ced_onbuy/profile/update', 'token=' . $this->session->data['token'] . '&id=' . $result['id'] . $url, 'SSL')
			);

			$data['profiles'][] = array(
				'id' => $result['id'],
				'title'      => $result['title'],
				'status'     => ($result['status']) ? $this->language->get('text_enabled') : $this->language->get('text_disabled'),
				'selected'       => isset($this->request->post['selected']) && in_array($result['id'], $this->request->post['selected']),
				'action'         => $action
			);
		}	

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_list'] = $this->language->get('text_list');

		$data['column_title'] = $this->language->get('column_title');
		$data['column_id'] = $this->language->get('column_id');
		$data['column_status'] = $this->language->get('column_status');

		$data['column_action'] = $this->language->get('column_action');		

		$data['button_insert'] = $this->language->get('button_insert');
		$data['button_delete'] = $this->language->get('button_delete');
		$data['button_edit'] = $this->language->get('button_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_title'] = $this->url->link('ced_onbuy/profile', 'token=' . $this->session->data['token'] . '&sort=title' . $url, 'SSL');
		$data['sort_id'] = $this->url->link('ced_onbuy/profile', 'token=' . $this->session->data['token'] . '&sort=id' . $url, 'SSL');
		$data['sort_status'] = $this->url->link('ced_onbuy/profile', 'token=' . $this->session->data['token'] . '&sort=status' . $url, 'SSL');

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $profile_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->text = $this->language->get('text_pagination');
		$pagination->url = $this->url->link('ced_onbuy/profile', 'token=' . $this->session->data['token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($profile_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($profile_total - $this->config->get('config_limit_admin'))) ? $profile_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $profile_total, ceil($profile_total / $this->config->get('config_limit_admin')));


		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('ced_onbuy/profile_list.tpl', $data));
	}

	protected function getForm() {

		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_form'] = !isset($this->request->get['id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
		$data['text_default'] = $this->language->get('text_default');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['entry_title'] = $this->language->get('entry_title');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_store'] = $this->language->get('entry_store');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		$data['tab_general'] = $this->language->get('tab_general');
		$data['tab_attribute'] = $this->language->get('tab_attribute');
		$data['tab_onbuy_category'] = $this->language->get('tab_onbuy_category');
		$data['tab_default_attributes'] = $this->language->get('tab_default_attributes');

		$data['entry_uid'] = $this->language->get('entry_uid');
		$data['entry_category_id'] = $this->language->get('entry_category_id');
		$data['entry_product_name'] = $this->language->get('entry_product_name');
		$data['entry_mpn'] = $this->language->get('entry_mpn');
		$data['entry_product_codes'] = $this->language->get('entry_product_codes');
		$data['entry_description'] = $this->language->get('entry_description');
		$data['entry_rrp'] = $this->language->get('entry_rrp');

		$data['entry_manufacturer'] = $this->language->get('entry_manufacturer');
		$data['entry_category'] = $this->language->get('entry_category');
		$data['entry_store_attribute'] = $this->language->get('entry_store_attribute');
		$data['entry_onbuy_attribute'] = $this->language->get('entry_onbuy_attribute');
		$data['entry_language'] = $this->language->get('entry_language');
		$data['entry_onbuy_category'] = $this->language->get('entry_onbuy_category');

		$data['entry_published'] = $this->language->get('entry_published');
		$data['entry_summary_points'] = $this->language->get('entry_summary_points');
		$data['entry_brand_name'] = $this->language->get('entry_brand_name');
		$data['entry_brand_id'] = $this->language->get('entry_brand_id');
		$data['entry_condition'] = $this->language->get('entry_condition');
		$data['entry_delivery'] = $this->language->get('entry_delivery');
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['title'])) {
			$data['error_title'] = $this->error['title'];
		} else {
			$data['error_title'] = array();
		}

		if (isset($this->error['store'])) {
			$data['error_store'] = $this->error['store'];
		} else {
			$data['error_store'] = array();
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('ced_onbuy/profile', 'token=' . $this->session->data['token'] . $url, 'SSL')
		);

		if (!isset($this->request->get['id'])) {
			$data['action'] = $this->url->link('ced_onbuy/profile/insert', 'token=' . $this->session->data['token'] . $url, 'SSL');
			$data['profile_id'] = '0';
		} else {
			$data['profile_id'] = $this->request->get['id'];
			$data['action'] = $this->url->link('ced_onbuy/profile/update', 'token=' . $this->session->data['token'] . '&id=' . $this->request->get['id'] . $url, 'SSL');
		}

		$data['cancel'] = $this->url->link('ced_onbuy/profile', 'token=' . $this->session->data['token'] . $url, 'SSL');
		$profile_info = array();
		if (isset($this->request->get['id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$profile_info = $this->model_ced_onbuy_profile->getProfile($this->request->get['id']);

			$default_attributes = json_decode($profile_info['default_mapping'], true);
			$profile_store = json_decode($profile_info['profile_store'], true);
            $categories = json_decode($profile_info['store_category'], true);
			$product_manufacturer = json_decode($profile_info['product_manufacturer'], true);
			$attributes = json_decode($profile_info['attributes'], true);

			if(!is_array($default_attributes) || empty($default_attributes))
                $default_attributes = array();
            if(!is_array($profile_store) || empty($profile_store))
                $profile_store = array();
            if(!is_array($categories) || empty($categories))
                $categories = array();
            if(!is_array($product_manufacturer) || empty($product_manufacturer))
                $product_manufacturer = array();
            if(!is_array($attributes) || empty($attributes))
                $attributes = array();
		}

		$data['token'] = $this->session->data['token'];

		$this->load->model('setting/store');

		$data['stores'] = $this->model_setting_store->getStores();

		if (isset($this->request->post['profile_store'])) {
			$data['profile_store'] = $this->request->post['profile_store'];
		} elseif (!empty($profile_store)) {
			$data['profile_store'] = $profile_store;
		} else {
			$data['profile_store'] = array(0);
		}

        // Store Categories
        $this->load->model('catalog/category');

        if (isset($this->request->post['product_category'])) {
            $categories = $this->request->post['product_category'];
        } elseif (!empty($categories)) {
            $categories = $categories;
        } else {
            $categories = array();
        }

        $data['product_categories'] = array();

        foreach ($categories as $category_id) {
            $category_info = $this->model_catalog_category->getCategory($category_id);

            if ($category_info) {
                $data['product_categories'][] = array(
                    'category_id' => $category_info['category_id'],
                    'name' => ($category_info['path']) ? $category_info['path'] . ' &gt; ' . $category_info['name'] : $category_info['name']
                );
            }
        }

        // Manufacturer
        $this->load->model('catalog/manufacturer');

        if (isset($this->request->post['manufacturer_id'])) {
            $product_manufacturer = $this->request->post['manufacturer_id'];
        } elseif (!empty($product_manufacturer)) {
            $product_manufacturer = $product_manufacturer;
        } else {
            $product_manufacturer = array();
        }

        $data['product_manufacturers'] = array();

        foreach ($product_manufacturer as $manufacturer) {
            $manufacturer_info = $this->model_catalog_manufacturer->getManufacturer($manufacturer);

            if ($manufacturer_info) {
                $data['product_manufacturers'][] = array(
                    'manufacturer_id' => $manufacturer_info['manufacturer_id'],
                    'name' => $manufacturer_info['name']
                );
            }
        }

		$this->load->model('localisation/language');
		$data['languages'] = $this->model_localisation_language->getLanguages();
	
		if (isset($this->request->post['profile_language'])) {
			$data['profile_language'] = $this->request->post['profile_language'];
		} elseif (isset($profile_info['profile_language'])) {
			$data['profile_language'] = $profile_info['profile_language'];
		} else {
			$data['profile_language'] = 1;
		}

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($profile_info)) {
			$data['status'] = $profile_info['status'];
		} else {
			$data['status'] = 1;
		}

		if (isset($this->request->post['title'])) {
			$data['title'] = $this->request->post['title'];
		} elseif (!empty($profile_info)) {
			$data['title'] = $profile_info['title'];
		} else {
			$data['title'] = '';
		}

        // Onbuy Category
        $this->load->model('ced_onbuy/category');

        $data['categories'] = $this->model_ced_onbuy_category->getCedonbuyCategory();

        // $mapped_onbuy_category_id = $this->config->get('onbuy_category');
        // if(!empty($mapped_fruugo_category_id)){
        //     $sql = $this->db->query("SELECT name FROM `". DB_PREFIX ."cedonbuy_category` WHERE category_id = '". $mapped_onbuy_category_id ."' ");
        //     $mapped_onbuy_category = $sql->row;
        // }

        if (isset($this->request->post['onbuy_category'])) {
            $data['onbuy_category'] = $this->request->post['onbuy_category'];
        } 
        // elseif(isset($mapped_onbuy_category) && !empty($mapped_onbuy_category['category_name'])){
        //     $data['onbuy_category'] = $mapped_onbuy_category['name'];
        // } 
        elseif (!empty($profile_info['onbuy_category'])) {
            $data['onbuy_category'] = $profile_info['onbuy_category'];
        } else {
            $data['onbuy_category'] = '';
        }

		if (isset($this->request->post['onbuy_category_name'])) {
			$data['onbuy_category_name'] = $this->request->post['onbuy_category_name'];
		} elseif (!empty($profile_info)) {
			$data['onbuy_category_name'] = $profile_info['onbuy_category_name'];
		} else {
			$data['onbuy_category_name'] = '';
		}

		//Validation Array
		$this->load->library('cedonbuy');
		$cedonbuy = Cedonbuy::getInstance($this->registry);
		$validation_array = $cedonbuy->getValidationArray();
		$data['attribute_description'] = array();
		foreach($validation_array as $key => $value)
		{
			$data['attribute_description'][$key] = $value['description'];
		}

        $data['system_attributes'] = $this->model_ced_onbuy_profile->getAttributesMapping();

        if (isset($this->request->post['attributes'])) {
			
			foreach($this->request->post['attributes'] as $key => $value)
			{
				$data['mapped_attributes_'.$key] = $value;
			}
		} elseif (!empty($attributes)) {
			foreach($attributes as $key => $value)
			{
				$data['mapped_attributes_'.$key] = $value;
			}
		} else {
			$data['mapped_attributes'] = array();
		}

		$data['conditions'] = $this->model_ced_onbuy_profile->getConditions();

		$this->load->model('ced_onbuy/logistics');

		$data['deliveries'] = $this->model_ced_onbuy_logistics->getLogistics();

        if (isset($this->request->post['default_attributes'])) {
			$data['default_attributes'] = $this->request->post['default_attributes'];
		} elseif (!empty($default_attributes)) {
			$data['default_attributes'] = $default_attributes;
		} else {
			$data['default_attributes'] = array();
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('ced_onbuy/profile_form.tpl', $data));
	}

	protected function validateForm() {
		return true;
		if (!$this->user->hasPermission('modify', 'ced_onbuy/profile')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		foreach ($this->request->post['profile_description'] as $language_id => $value) {
			if ((utf8_strlen($value['title']) < 3) || (utf8_strlen($value['title']) > 64)) {
				$this->error['title'][$language_id] = $this->language->get('error_title');
			}

			if (utf8_strlen($value['description']) < 3) {
				$this->error['description'][$language_id] = $this->language->get('error_description');
			}
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'ced_onbuy/profile')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}

	public function autocomplete()
	{
		$json = array();

		if (isset($this->request->get['filter_name']) || isset($this->request->get['filter_id'])) {
			$this->load->model('ced_onbuy/profile');

			$filter_data = array(
				'filter_name' => isset($this->request->get['filter_name']) ? $this->request->get['filter_name'] : '',
				'filter_id'   => isset($this->request->get['filter_id']) ? $this->request->get['filter_id'] : '',
				'start'       => 0,
				'limit'       => 5
			);

			$results = $this->model_ced_onbuy_profile->getOnbuyBrands($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'brand_id'    => $result['brand_id'],
					'name'            => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'))
				);
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function fetchBrand($offset = 0) 
	{
		$this->load->language('ced_onbuy/profile');
		$this->load->model('ced_onbuy/profile');

        $cedonbuy = Cedonbuy::getInstance($this->registry);
		$url = 'brands';
		$params = array(
			'filter' => array(
				'name' => ''
				),
			'sort' => array(
				'name' => 'asc'
				),
			'limit' => '100',
			'offset' => $offset
			);
        $access_token = $this->config->get('ced_onbuy_access_token');
        $access_token_expiry = $this->config->get('ced_onbuy_expires_at');
        $now = strtotime(date('Y-m-d h:i:s a'));
        
        if(!empty($access_token) && !empty($access_token_expiry) && $access_token_expiry > $now)
        {
        	$cedonbuy->updateAccessToken();
        }
        $response = $cedonbuy->getRequest($url, $params);

        if(isset($response['status']) && $response['status'] == true)
        {
        	$brand_data = $response['response'];
        	$brands = $brand_data['results'];
            $total_rows = count($brands);

        	if ($brands && count($brands)) 
        	{
        		$status = $this->model_ced_onbuy_profile->addBrands($brands);

        		if($total_rows >= '100')
        		{
        			//$total_rows = $brand_data['metadata']['total_rows'];
        			$noOfBrandsToSkip = $offset + '100';
        			//$total_rows_left = $total_rows - $noOfBrandsToSkip;
        			// if($total_rows_left > '0')
		         //    {
		            	$this->fetchBrand($noOfBrandsToSkip);
		            //}
        		}
        		
	        	// $array_chunk_count = ceil($total_brand/10);
	         //    $brands_array = array_chunk($brands,$array_chunk_count);
	            //echo '<pre>'; print_r($brands_array); die;
	            //$data['brands_array'] = json_encode($brands_array);

	            $this->session->data['success'] = 'Brand(s) fetched Successfully!';
        	} else {
	            $this->error['warning'] = 'No Brands Left';
	            
	        }
        } else {
        	$this->error['warning'] = $response['response'];
        }
        $this->getList();
    }
    
}
?>
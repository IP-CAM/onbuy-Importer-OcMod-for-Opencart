<?php

class Cedonbuy {
    private $logger;
    // private $api_url = 'https://merchant.onbuy.com/api/v2/';
    // private $api_version = 'v2';
    private static $instance;

    /**
     * @param  object  $registry  Registry Object
     */
    public static function getInstance($registry) {
        if (is_null(static::$instance)) {
            static::$instance = new static($registry);
        }

        return static::$instance;
    }

    /**
     * @param  object  $registry  Registry Object
     *
     *   $registry->get('log');
     *   $registry->get('db');
     *   $registry->get('config');
     */
    public function __construct($registry) {
        $this->logger   = $registry->get('log');
        $this->db       = $registry->get('db');
        $this->config   = $registry->get('config');
        $this->currency = $registry->get('currency');
        //$this->tax      = new Tax($registry);
    }

    public function isEnabled()
    {

        $flag=false;

        if ($this->config->get('ced_onbuy_status')) {

            $flag=true;

            $this->_init();
        }
        return $flag;
    }

    public function _init(){

        $this->api_url = $this->config->get('ced_onbuy_api_url');
        $this->secure_key = $this->config->get('ced_onbuy_secret_key');
        $this->consumer_key = $this->config->get('ced_onbuy_consumer_key');
        $this->access_token = $this->config->get('ced_onbuy_access_token');
        $this->log("url: ".$this->api_url);
        $this->log("Secure Key: ".$this->secure_key);
        $this->log("Consumer Key: ".$this->consumer_key);
    }

    public function isCedOnbuyInstalled()
    {
        if ($this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "cedonbuy_install'")->num_rows) {
            return true;
        } else {
            return false;
        }
    }

    public function installCedOnbuy()
    {
        // Category
        $cedonbuy_category = $this->db->query("
                CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_category` (
                `id` int(15) NOT NULL AUTO_INCREMENT,
                `category_id` int(15) NULL,
                `name` text NULL,
                `category_tree` text NULL,
                `category_type_id` int(11) NULL,
                `category_type` text NULL,
                `parent_id` int(11) NULL,
                `lvl` int(11) NULL,
                `product_code_required` int(11) NULL,
                `can_list_in` int(11) NULL,
                `commission_tier_id` int(11) NULL,
                `google_category` longtext NULL,
                PRIMARY KEY  (`id`)
                ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
            ");

        if ($cedonbuy_category)
            $this->log("cedonbuy_category table created", 6, true);

        // Profile
        $cedonbuy_profile = $this->db->query("
                CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_profile` (
                 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
                  `title` text COLLATE utf8_unicode_ci NOT NULL,
                  `status` int(11) NOT NULL,
                  `product_manufacturer` text COLLATE utf8_unicode_ci NOT NULL,
                  `store_category` longtext COLLATE utf8_unicode_ci NOT NULL,
                  `profile_store` text COLLATE utf8_unicode_ci NOT NULL,
                  `profile_language` int(11) NOT NULL,
                  `attributes` longtext COLLATE utf8_unicode_ci NOT NULL,
                  `onbuy_category` longtext COLLATE utf8_unicode_ci NOT NULL,
                  `onbuy_category_name` text COLLATE utf8_unicode_ci NOT NULL,
                  `onbuy_categories` longtext COLLATE utf8_unicode_ci NOT NULL,
                  `profile_attribute_mapping` longtext COLLATE utf8_unicode_ci NOT NULL,
                  `profile_feature_mapping` longtext COLLATE utf8_unicode_ci NOT NULL,
                  `default_mapping` text COLLATE utf8_unicode_ci NOT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
            ");

        if ($cedonbuy_profile)
            $this->log("cedonbuy_profile table created", 6, true);

        // Profile Product
        $cedonbuy_profile_products = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_profile_products` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `product_id` int(11) NOT NULL,
          `profile_id` int(11) NOT NULL,
          `sku` text NOT NULL,
          `onbuy_status` text COLLATE utf8_unicode_ci NOT NULL,
          `error_message` longtext COLLATE utf8_unicode_ci NOT NULL,
          `onbuy_queue_id` text NOT NULL,
          `opc` text NOT NULL,
          PRIMARY KEY (`id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ";

        $created = $this->db->query($cedonbuy_profile_products);
        if ($created)
            $this->log("cedonbuy_profile_products table created", 6, true);

        // Product Brand
        $cedonbuy_brand = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_brand` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `brand_id` int(11) NOT NULL,
          `name` text COLLATE utf8_unicode_ci NOT NULL,
          `brand_type_id` int(11) NOT NULL,
          `type` text COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ";

        $created = $this->db->query($cedonbuy_brand);
        if ($created)
            $this->log("cedonbuy_brand table created", 6, true);

        // Attributes
        $cedonbuy_attribute = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_attribute` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `group_id` bigint(20) NOT NULL,
          `group_name` text COLLATE utf8_unicode_ci NOT NULL,
          `detail_id` bigint(20) NOT NULL,
          `name` text COLLATE utf8_unicode_ci NOT NULL,
          `options` longtext COLLATE utf8_unicode_ci NOT NULL,
          `is_mandatory` tinyint(1) NOT NULL,
          `category_id` bigint(20) NOT NULL,
          PRIMARY KEY (`id`)
        )ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ";

        $created = $this->db->query($cedonbuy_attribute);
        if ($created)
            $this->log("cedonbuy_attribute table created", 6, true);

        // Attributes
        $cedonbuy_feature = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_feature` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `group_id` bigint(20) NOT NULL,
          `feature_id` bigint(20) NOT NULL,
          `name` text COLLATE utf8_unicode_ci NOT NULL,
          `options` longtext COLLATE utf8_unicode_ci NOT NULL,
          `is_mandatory` tinyint(1) NOT NULL,
          `category_id` bigint(20) NOT NULL,
          PRIMARY KEY (`id`)
        )ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ";

        $created = $this->db->query($cedonbuy_feature);
        if ($created)
            $this->log("cedonbuy_feature table created", 6, true);

        // Variants
        $cedonbuy_variants = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_variants` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `feature_id` bigint(20) NOT NULL,
          `variant_key` text COLLATE utf8_unicode_ci NOT NULL,
          `name` text COLLATE utf8_unicode_ci NOT NULL,
          `options` longtext COLLATE utf8_unicode_ci NOT NULL,
          `category_id` bigint(20) NOT NULL,
          PRIMARY KEY (`id`)
        )ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ";

        $created = $this->db->query($cedonbuy_variants);
        if ($created)
            $this->log("cedonbuy_variants table created", 6, true);

        // Product Condition
        $cedonbuy_conditions = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_conditions` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `condition_id` int(11) NOT NULL,
          `name` text COLLATE utf8_unicode_ci NOT NULL,
          `code` text COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ";

        $created = $this->db->query($cedonbuy_conditions);
        if ($created)
            $this->log("cedonbuy_conditions table created", 6, true);

        // Insert Conditions
        $cedonbuy_conditions_insert = "INSERT IGNORE INTO `" . DB_PREFIX . "cedonbuy_conditions` (`id`, `condition_id`, `name`, `code`) VALUES
                  (1, 1, 'New', 'new'),
                  (2, 2, 'Refurbished', 'refurbished'),
                  (3, 4, 'Excellent', 'excellent'),
                  (4, 5, 'Very Good', 'verygood'),
                  (5, 6, 'Good', 'good'),
                  (6, 7, 'Average', 'average'),
                  (7, 8, 'Below Average', 'belowaverage');";

        $created = $this->db->query($cedonbuy_conditions_insert);
        if ($created)
            $this->log("cedonbuy_conditions_insert table created", 6, true);

        // Product Cron
        $cedonbuy_product_cron = $this->db->query("
                CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_products_cron` (
                `id` int(15) NOT NULL AUTO_INCREMENT,
                `inventory_chunk` longtext NULL,
                `type` text NULL,
                PRIMARY KEY  (`id`)
                ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
            ");

        if ($cedonbuy_product_cron)
            $this->log("cedonbuy_product_cron table created", 6, true);


        // Product Logistics
        $cedonbuy_logistics = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_logistics` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `country_id` int(11) NOT NULL,
          `country` text COLLATE utf8_unicode_ci NOT NULL,
          `country_sub_region_id` int(11) NOT NULL,
          `country_sub_region` text COLLATE utf8_unicode_ci NOT NULL,
          `delivery_charge_type_id` int(11) NOT NULL,
          `delivery_charge_type` text COLLATE utf8_unicode_ci NOT NULL,
          `delivery_type_id` int(11) NOT NULL,
          `delivery_type` text COLLATE utf8_unicode_ci NOT NULL,
          `delivery_time_id` int(11) NOT NULL,
          `min_days` int(11) NOT NULL,
          `max_days` int(11) NOT NULL,
          `delivery_time` text COLLATE utf8_unicode_ci NOT NULL,
          `price` float NOT NULL,
          `additional_price` float NOT NULL,
          `template_name` text COLLATE utf8_unicode_ci NOT NULL,
          `seller_delivery_template_id` int(11) NOT NULL,
          `is_default_template` boolean NOT NULL,
          `delivery_tag` text COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ";

        $created = $this->db->query($cedonbuy_logistics);
        if ($created)
            $this->log("cedonbuy_logistics table created", 6, true);

       // Tracking Provier
        $cedonbuy_tracking = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_tracking` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `tracking_id` int(11) NOT NULL,
          `name` text COLLATE utf8_unicode_ci NOT NULL,
          `url` text COLLATE utf8_unicode_ci NOT NULL,
          PRIMARY KEY (`id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ";

        $created = $this->db->query($cedonbuy_tracking);
        if ($created)
            $this->log("cedonbuy_tracking table created", 6, true);

        // Order
        $cedonbuy_order = $this->db->query("
                CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_order` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `opencart_order_id` int(11) NULL,
                `onbuy_order_id` text NULL,
                `order_data` longtext NULL,
                `order_place_date` datetime NULL,
                `onbuy_status` text NULL,
                PRIMARY KEY  (`id`)
              ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
            ");

        if ($cedonbuy_order)
            $this->log("cedonbuy_order table created", 6, true);

        // Order Error
        $cedonbuy_order_error = $this->db->query("
                CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedonbuy_order_error` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `sku` text NULL,
                  `onbuy_order_id` text NULL,
                  `order_data` longtext NULL,
                  `reason` text NULL,
                  `cancel_qty` int(10),
                  PRIMARY KEY  (`id`)
                ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
            ");

        if ($cedonbuy_order_error)
            $this->log("cedonbuy_order_error table created", 6, true);
    }

    public function postRequest($endpoint, $post_params, $method = "POST")
    {
        $response = array();
        $this->_init();
        $url = $this->api_url . $endpoint;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);

        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_params);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        $response = json_decode($response, true);
        
        //$err = curl_error($ch);
        //$status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        curl_close($ch);
        $this->log('Cedonbuy::postRequest URL', 6, true);
        $this->log($url, 6, true);
        $this->log('Cedonbuy::postRequest Params', 6, true);
        $this->log($post_params, 6, true);
        $this->log('Cedonbuy::postRequest Response', 6, true);
        $this->log($response, 6, true);

        if(isset($response['error']) && !empty($response['error']))
        {
            $response = $response['error'];
            return array(
                'status' => false,
                'response' => $response['message']
            );
        } else {
            return array(
                'status' => true,
                'response' => $response
            );
        }
    }

    public function getRequest($endpoint, $get_params)
    {
      $this->_init();
      $params = http_build_query($get_params);
      $url = $this->api_url . $endpoint . '?' . $params;
      
      $header = array();
      $header = array(
          'Authorization:'.$this->access_token);
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_POST, false);
      curl_setopt($ch, CURLOPT_ENCODING, '');
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
      curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
      $response = curl_exec($ch);
      
      $response = json_decode($response, true);
      
      //$status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
      curl_close($ch);
      $this->log('Cedonbuy::getRequest URL', 6, true);
      $this->log($url, 6, true);
      $this->log('Cedonbuy::getRequest Params', 6, true);
      $this->log($get_params, 6, true);
      $this->log('Cedonbuy::getRequest Response', 6, true);
      $this->log($response, 6, true);
      if(isset($response['error']) && !empty($response['error']))
      {
        $response = $response['error'];
        return array(
          'status' => false,
          'response' => $response['message']
        );
      } else {
        return array(
          'status' => true,
          'response' => $response
        );
      }
    }

    public function putRequest($endpoint, $post_params, $method = "PUT")
    {
        $response = array();
        $this->_init();
        $url = $this->api_url . $endpoint;
        $header = array();
        // if($method == 'PUT')
        // {
        $header = array(
            "Authorization:".$this->access_token,
            "Content-Type: application/json");
        //}
        // print_r($post_params); die;
        $post_params = json_encode($post_params);
        // print_r($post_params); die;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);

        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_params);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $response = curl_exec($ch);
        $response = json_decode($response, true);
        // echo '<pre>'; print_r($response); die;
        //$err = curl_error($ch);
        //$status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $this->log('Cedonbuy::postRequest URL', 6, true);
        $this->log($url, 6, true);
        $this->log('Cedonbuy::postRequest Params', 6, true);
        $this->log($post_params, 6, true);
        $this->log('Cedonbuy::postRequest Response', 6, true);
        $this->log($response, 6, true);

        if(isset($response['error']) && !empty($response['error']))
        {
            $response = $response['error'];
            return array(
                'status' => false,
                'response' => $response['message']
            );
        } else {
            return array(
                'status' => true,
                'response' => $response
            );
        }
    }

    public function log($data, $force_log =true ) 
    {
        if ($this->config->get('ced_onbuy_enable_logging') || $force_log) {
            $backtrace = debug_backtrace();
            $log = new Log('ced_onbuy.log');
            $log->write('(' . $backtrace[1]['class'] . '::' . $backtrace[1]['function'] . ') - ' . print_r($data, true));
        }
    }

    public function updateAccessToken()
    {
        $url = 'auth/request-token';
        $params = array(
            'secret_key' => $this->config->get('ced_onbuy_secret_key'),
            'consumer_key' => $this->config->get('ced_onbuy_consumer_key')
            );
        $auth = $this->postRequest($url, $params);
        // echo '<pre>'; print_r($auth); die;
        if(isset($auth['status']) && $auth['status'] == true)
        {
            $access_token = $auth['response']['access_token'];
            $expires_at = $auth['response']['expires_at'];
            
            $this->editSettingValue('ced_onbuy', 'ced_onbuy_access_token' , $access_token);
            $this->editSettingValue('ced_onbuy', 'ced_onbuy_expires_at' , $expires_at);
        }
    }

    public function editSettingValue($code = '', $key = '', $value = '', $store_id = 0) 
    {
        if (!is_array($value)) {
            $this->db->query("UPDATE " . DB_PREFIX . "setting SET `value` = '" . $this->db->escape($value) . "', serialized = '0'  WHERE `code` = '" . $this->db->escape($code) . "' AND `key` = '" . $this->db->escape($key) . "' AND store_id = '" . (int)$store_id . "'");
        } else {
            $this->db->query("UPDATE " . DB_PREFIX . "setting SET `value` = '" . $this->db->escape(json_encode($value)) . "', serialized = '1' WHERE `code` = '" . $this->db->escape($code) . "' AND `key` = '" . $this->db->escape($key) . "' AND store_id = '" . (int)$store_id . "'");
        }
    }

    public function getAllOnbuyProducts()
    {
        $result = $this->db->query("SELECT `store_category` FROM `" . DB_PREFIX . "cedonbuy_profile`");
        if ($result && $result->num_rows) {
            $product_ids = array();
            $categories_mapped =array();
            foreach ($result->rows as $key => $store_category) {
                $categories_mapped = array_merge($categories_mapped, json_decode($store_category['category'], true));
            }

            if(count($categories_mapped)){
                $categories_mapped = array_unique($categories_mapped);
                $results = $this->db->query("SELECT product_id FROM `".DB_PREFIX."product_to_category` WHERE category_id IN (".implode(',', $categories_mapped).")");

                if ($results->num_rows) {
                    foreach ($results->rows as $key => $value) {
                        $product_ids[] =  $value['product_id'];
                    }
                }
                return $product_ids;
            }
            return array();
        } else {
            return array();
        }
    }

    public function getAllMappedProducts()
    {
      $query = $this->db->query("SELECT `product_id` FROM `" . DB_PREFIX . "cedonbuy_profile_products` WHERE `profile_id` > '0' ");
      $result = $query->rows;
      $product_ids = array();
      if(is_array($result) && count($result)) 
      {
          foreach ($result as $key => $value) {
              if (isset($value['product_id']) && $value['product_id']) {
                  $product_ids[] = $value['product_id'];
              }
          }
      }
      return $product_ids;
    }

    public function uploadProducts($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0){
            $product_ids = $this->getAllOnbuyProducts();
        }
        if(count($product_ids)) {
            $data = array();
            $error_data = '';
              try 
              {
                foreach($product_ids as $key => $product_id)
                {
                  $product_id = (int)$product_id;
                  $product_data_array = $this->prepareOnbuyProduct($product_id);

                   if(!isset($product_data_array['error_message']))
                   {
                      $data[] = $product_data_array;
                   } else {
                      $error_data .= $product_data_array['error_message'] . ',';
                   }
                }
                 $params = array(
                  'site_id' => $this->config->get('ced_onbuy_site_id'),
                  'products' => $data,
                  );
                 
                 if(isset($params) && !empty($params) && is_array($params))
                  {
                    $url = 'products';
                    //$params = json_encode($final_product_array);

                    $access_token = $this->config->get('ced_onbuy_access_token');
                    $access_token_expiry = $this->config->get('ced_onbuy_expires_at');
                    $now = strtotime(date('Y-m-d h:i:s a'));
                    
                    if(!empty($access_token) && !empty($access_token_expiry) && $access_token_expiry > $now)
                    {
                      $this->updateAccessToken();
                    }
                    //echo '<pre>'; print_r($params); die;
                    $response = $this->putRequest($url, $params, "POST");
                    // echo '<pre>'; print_r($response); die;
                    if(isset($response['status']) && $response['status'] == true)
                    {
                      $response = $response['response'];
                      if(isset($response['results']) && $response['results'])
                      {
                        $this->updateProductQueueID($response['results']);
                        return array('success' => true, 'message' => 'Product(s) uploaded Successfully!', 'error' => $error_data);
                      }
                    } else {
                      return array('success' => false, 'message' => !empty($response['response']) ? $response['response'] : 'Product Not Uploaded.');
                    }
                  }
              } catch (Exception $e) {
                  return array('success' => false, 'message' => 'No Response From Onbuy');
              }
            //echo '<pre>'; print_r($response); die;
            //return $data;
        }
    }

    public function updateProductQueueID($data = array())
    {
      if(isset($data) && $data)
      {
        foreach($data as $key => $value)
        {
          $sql = $this->db->query("SELECT `product_id` FROM `". DB_PREFIX ."product` WHERE `sku` = '". $value['uid'] ."' ");
          if($sql->num_rows)
          {
            $this->db->query("UPDATE `". DB_PREFIX ."cedonbuy_profile_products` SET `onbuy_queue_id` = '". $value['queue_id'] ."', `sku` = '". $value['uid'] ."' WHERE `product_id` = '". $sql->row['product_id'] ."'  ");
          }
        }
      }
    }

    public function removeNullValuesFromFinalProducts($data = array())
    {
        if (count($data)) {
            foreach ($data as $key => $value) {

                if(!$value || ((string)$value == '0000-00-00') || $value == '0.00' || $value == '0')
                    unset($data[$key]);

                if($key == 'category' || $key == 'description' || $key == 'main_image'){
                    $data['category'] = htmlspecialchars_decode($data['category']);
                    $data['description'] = htmlspecialchars_decode($data['description']);
                    $data['main_image'] = stripslashes($data['main_image']);
                    // $data['main_image'] = 'http://demo.cedcommerce.com/integration/opencart2.0/image/cache/catalog/demo/hp_2-100x100.jpg';
                }

                if($key == 'tags')
                    $data['tags'] = $data['tags'] . ',';
                if(in_array($key,array('profile_id')))
                    unset($data[$key]);
                if(!empty($key['extra_images']))
                    $data['extra_images'] = stripslashes($data['extra_images']);
            }
        }
        return $data;
    }

    public function prepareOnbuyProduct($product_id)
    {
      if($product_id)
      {
        $query = $this->db->query("SELECT `profile_id` FROM `". DB_PREFIX ."cedonbuy_profile_products` WHERE `product_id` = '".(int)$product_id."' AND `profile_id` != '0' ");
        $result = $query->row;

          if(isset($result['profile_id']) && $result['profile_id'])
          {
            $fetched_mapped_data = $this->db->query("SELECT * FROM `" . DB_PREFIX . "cedonbuy_profile` WHERE `id` = '" . (int)$result['profile_id'] . "' ");
              $mapped_data = $fetched_mapped_data->row;

              $onbuy_array = array();
              if(isset($mapped_data) && $mapped_data)
              {
                $language_id = !empty($mapped_data['profile_language']) ? $mapped_data['profile_language'] : $this->config->get('config_language_id'); 
                $attributes = json_decode($mapped_data['attributes'], true);
                $default_attributes = json_decode($mapped_data['default_mapping'], true);
                $profile_store = json_decode($mapped_data['profile_store'], true);
                $categories = json_decode($mapped_data['store_category'], true);
                $product_manufacturer = json_decode($mapped_data['product_manufacturer'], true);
                $profile_attribute_mapping = json_decode($mapped_data['profile_attribute_mapping'], true);

                if(!is_array($attributes) || empty($attributes))
                    $attributes = array();
                if(!is_array($default_attributes) || empty($default_attributes))
                    $default_attributes = array();
                if(!is_array($profile_store) || empty($profile_store))
                    $profile_store = array();
                if(!is_array($categories) || empty($categories))
                    $categories = array();
                if(!is_array($product_manufacturer) || empty($product_manufacturer))
                    $product_manufacturer = array();
                if(!is_array($profile_attribute_mapping) || empty($profile_attribute_mapping))
                    $profile_attribute_mapping = array();
                if(!is_array($profile_feature_mapping) || empty($profile_feature_mapping))
                    $profile_feature_mapping = array();

                // Product Data
                $product = $this->getProduct($product_id);

                // Onbuy Category Name
                if(isset($mapped_data['onbuy_category']) && $mapped_data['onbuy_category'])
                    $onbuy_array['category_id'] = $mapped_data['onbuy_category'];
                else
                    $onbuy_array['category_id'] = '';

                  // Attributes
                  if(isset($attributes) && !empty($attributes))
                  {
                    foreach($attributes as $key => $value) 
                    {
                      foreach($product as $pKey => $pValue)
                      {
                        if($pKey == $value)
                        {
                          $onbuy_array[$key] = $pValue;
                        }
                      }
                      if(empty($onbuy_array[$key]))
                        $onbuy_array[$key] = '';
                    }
                    if(isset($onbuy_array['product_codes']) && !empty($onbuy_array['product_codes']))
                    {
                      $onbuy_array['product_codes'] = array($onbuy_array['product_codes']);
                    } else {
                      $onbuy_array['product_codes'] = array();
                    }
                  }

                  // Default Attribute
                  if(isset($default_attributes) && !empty($default_attributes))
                  {
                    foreach($default_attributes as $key => $value) 
                    {     
                      if(!empty($value))
                      {
                          $onbuy_array[$key] = $value;
                      } else {
                          $onbuy_array[$key] = '';
                      }   
                    }
                    if(isset($onbuy_array['summary_points']) && !empty($onbuy_array['summary_points']))
                    {
                      $onbuy_array['summary_points'] = array($onbuy_array['summary_points']);
                    } else {
                      $onbuy_array['summary_points'] = array();
                    }
                  }

                  $query = $this->db->query("SELECT image FROM `" . DB_PREFIX . "product` WHERE product_id = '" . $product_id . "' ");
                  $res = $query->row;

                  if(isset($res['image']) && $res['image'])
                      $onbuy_array['default_image'] = html_entity_decode(HTTPS_CATALOG . "image/" . $res['image']);
                  else
                      $onbuy_array['default_image'] = '';

                  $query = $this->db->query("SELECT image FROM `" . DB_PREFIX . "product_image` WHERE product_id = '" . $product_id . "' ");
                  $images = $query->rows;

                  if(isset($images) && count($images))
                  {
                    $additional_images = array();
                    foreach($images as $key => $image)
                    {
                      $additional_images[] = html_entity_decode(HTTPS_CATALOG . "image/" . $image['image']);
                    }
                    if(count($additional_images))
                      $onbuy_array['additional_images'] = $additional_images;
                    else
                      $onbuy_array['additional_images'] = '';
                  }
                  $onbuy_array['videos'] = array();
                  $onbuy_array['documents'] = array();
                  if(isset($onbuy_array['condition']) && $onbuy_array['condition'])
                  {
                    $onbuy_array['listings'] = $this->getProductListing($product, $onbuy_array['condition']);
                  }

                  // Technical Details
                  if(isset($profile_attribute_mapping) && !empty($profile_attribute_mapping))
                  {
                    $onbuy_array['technical_detail'] = $this->getCedOnbuyTechnicalDetails($product_id, $profile_attribute_mapping, $product);
                  }

                  // Features
                  if(isset($profile_feature_mapping) && !empty($profile_feature_mapping))
                  {
                    $onbuy_array['features'] = $this->getCedOnbuyFeatures($product_id, $profile_feature_mapping, $onbuy_array['category_id']);
                  }
              }

              if(count($onbuy_array))
                  return $onbuy_array;
              else
                return array('error_message' => 'Something went wrong while creating product'. $product_id);
          } else {
            return array('error_message' => 'Product '. $product_id .' does not exist in Profile');
          }
      }
      return array('error_message' => 'Product '. $product_id .'  not found.');
    }

    public function getProduct($product_id)
    {
        $product = false;
        $query = $this->db->query("SELECT DISTINCT *, (SELECT keyword FROM " . DB_PREFIX . "url_alias WHERE query = 'product_id=" . (int)$product_id . "' AND language_id = '".$this->config->get('config_language_id')."') AS keyword FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) WHERE p.product_id = '" . (int)$product_id . "' AND pd.language_id = '" . (int)$this->config->get('config_language_id') . "'");
        if ($query->num_rows)
            $product = $query->row;
        return $product;
    }

    public function getCedOnbuyTechnicalDetails($product_id, $profile_attribute_mappings, $product)
    {
      if($product_id && isset($profile_attribute_mappings) && !empty($profile_attribute_mappings)) 
      {
        $attribute_onbuys = array();
        foreach ($profile_attribute_mappings as $profile_attribute_mapping)
        {
          $type = explode('-', $profile_attribute_mapping['store_attribute']);
          
          $attribute_onbuy = array();
          if(isset($type[0]) && ($type[0] == 'option'))
          {
              $attribute_onbuy = $this->getProductOptions($product_id, $profile_attribute_mapping, $type[1]);
          } else if(isset($type[0]) && ($type[0] == 'attribute')) 
          {
              $attribute_onbuy = $this->getProductAttributes($product_id, $profile_attribute_mapping, $type[1]);
          } else if(isset($type[0]) && ($type[0] == 'product')) 
          {
            $attribute_onbuy = $this->getMappedProductData($product, $profile_attribute_mapping, $type[1]);
          }
          $attribute_onbuys = array_merge($attribute_onbuys, $attribute_onbuy);
        }
        $attribute_onbuys = array_filter($attribute_onbuys);
        return $attribute_onbuys;
      } else {
        return array();
      }
    }

    public function getProductAttributes($product_id, $mapped_attributes, $attribute_id)
    {
      $product_attribute_data = array();

      if(isset($mapped_attributes['store_attribute']) && $mapped_attributes['store_attribute'] && isset($mapped_attributes['onbuy_attribute']) && $mapped_attributes['onbuy_attribute']) 
        {
            //$store_attribute = $mapped_attributes['store_attribute'];
          $onbuy_attribute_id = $mapped_attributes['onbuy_attribute'];

          $product_attribute_query = $this->db->query("SELECT `text` FROM " . DB_PREFIX . "product_attribute WHERE product_id = '" . (int)$product_id . "' AND attribute_id = '" . (int)$attribute_id . "' AND language_id = '" . (int)$this->config->get('config_language_id') . "' ");

            if($product_attribute_query && $product_attribute_query->num_rows) 
            {
              $product_attribute_data[] = array(
                'detail_id' =>(int) $onbuy_attribute_id, 
                'value' => $product_attribute_query->row['text'],
                'unit' => $mapped_attributes['units']
              );
            } else if(isset($mapped_attributes['default_values']) && !empty($mapped_attributes['default_values'])) 
            {
              $product_attribute_data[] = array(
                'detail_id' =>(int) $onbuy_attribute_id, 
                'value' => $mapped_attributes['default_values'],
                'unit' => $mapped_attributes['units']
              );
            }
        }
        return $product_attribute_data;
    }

    public function getProductOptions($product_id, $mapped_options, $option_id) 
    {
      $product_option_data = array();
      if(isset($mapped_options['store_attribute']) && $mapped_options['store_attribute'] && isset($mapped_options['onbuy_attribute']) && $mapped_options['onbuy_attribute']) 
        {
            //$store_attribute = $mapped_options['store_attribute'];
            $onbuy_attribute_id = $mapped_options['onbuy_attribute'];
            
            $product_option_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_option` po LEFT JOIN `" . DB_PREFIX . "option` o ON (po.option_id = o.option_id) LEFT JOIN `" . DB_PREFIX . "option_description` od ON (o.option_id = od.option_id) WHERE po.product_id = '" . (int)$product_id . "' AND  o.option_id = '".(int) $option_id."' AND  od.language_id = '" . (int)$this->config->get('config_language_id') . "'");

            if ($product_option_query->num_rows && isset($mapped_options['option'][$onbuy_attribute_id]))   
            {
              unset($mapped_options['option']['store_option']);
              unset($mapped_options['option']['store_option_id']);
              unset($mapped_options['option']['onbuy_option']);
              
                foreach($mapped_options['option'] as $option_values) 
                {
                  $product_option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_option_value WHERE product_option_id = '" . (int)$product_option_query->row['product_option_id'] . "' AND option_value_id  = '" . (int)$option_values['store_option_id'] . "' ");
                   
                    if($product_option_value_query->num_rows && isset($option_values['onbuy_option']) && $option_values['onbuy_option']) 
                    {
                      $product_option_data[] = array(
                        'detail_id' =>(int) $onbuy_attribute_id, 
                        'value' => $option_values['onbuy_option'],
                        'unit' => $mapped_options['units']
                      );
                    }
                }
            } else if(isset($mapped_options['default_values']) && !empty($mapped_options['default_values'])) 
            {
              $product_option_data[] = array(
                'detail_id' =>(int) $onbuy_attribute_id, 
                'value' => $mapped_options['default_values'],
                'unit' => $mapped_options['units']
              );
            }
        }
        return $product_option_data;
    }

    public function getMappedProductData($product, $mapped_products, $product_key)
    {
      $product_mapped_data = array();
      if(isset($mapped_products['store_attribute']) && $mapped_products['store_attribute'] && isset($mapped_products['onbuy_attribute']) && $mapped_products['onbuy_attribute']) 
        {
          $onbuy_attribute_id = $mapped_products['onbuy_attribute'];

          if($product && $product_key) 
          {
            foreach($product as $key => $value)
            {
              if($key == $product_key)
              {
                $product_mapped_data[] = array(
                  'detail_id' =>(int) $onbuy_attribute_id, 
                  'value' => $value,
                  'unit' => $mapped_attributes['units']
                );
              }
            }
          } else if(isset($mapped_products['default_values']) && !empty($mapped_products['default_values'])) 
            {
              $product_mapped_data[] = array(
                'detail_id' =>(int) $onbuy_attribute_id, 
                'value' => $mapped_products['default_values'],
                'unit' => $mapped_products['units']
              );
            }
        }
      return $product_mapped_data;
    }

    public function getCedOnbuyFeatures($product_id, $profile_feature_mappings, $category_id)
    {
      if($product_id && isset($profile_feature_mappings) && !empty($profile_feature_mappings)) 
      {
        $feature_onbuys = array();
        foreach ($profile_feature_mappings as $profile_feature_mapping)
        {
          $type = explode('-', $profile_feature_mapping['store_attribute']);
          $option_id = $type[1];
          
          $feature_onbuy = array();
          if(isset($profile_feature_mapping['store_attribute']) && $profile_feature_mapping['store_attribute'] && isset($profile_feature_mapping['onbuy_attribute']) && $profile_feature_mapping['onbuy_attribute']) 
          {
              //$store_attribute = $mapped_options['store_attribute'];
              $onbuy_attribute_id = $profile_feature_mapping['onbuy_attribute'];
              
              $product_option_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_option` po LEFT JOIN `" . DB_PREFIX . "option` o ON (po.option_id = o.option_id) LEFT JOIN `" . DB_PREFIX . "option_description` od ON (o.option_id = od.option_id) WHERE po.product_id = '" . (int)$product_id . "' AND  o.option_id = '".(int) $option_id."' AND  od.language_id = '" . (int)$this->config->get('config_language_id') . "'");

              if ($product_option_query->num_rows && isset($profile_feature_mapping['option'][$onbuy_attribute_id]))   
              {
                unset($profile_feature_mapping['option']['store_option']);
                unset($profile_feature_mapping['option']['store_option_id']);
                unset($profile_feature_mapping['option']['onbuy_option']);
                
                  foreach($profile_feature_mapping['option'] as $option_values) 
                  {
                    $product_option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_option_value WHERE product_option_id = '" . (int)$product_option_query->row['product_option_id'] . "' AND option_value_id  = '" . (int)$option_values['store_option_id'] . "' ");
                     
                      if($product_option_value_query->num_rows && isset($option_values['onbuy_option']) && $option_values['onbuy_option']) 
                      {
                        $response = $this->getVariantData($onbuy_attribute_id, $option_values['onbuy_option'], $category_id);
                        $feature_onbuy[] = array(
                          'option_id' =>(int) $response['option_id'], 
                          'name' => $option_values['onbuy_option'],
                          'hex' => isset($response['hex']) ? $response['hex'] : ''
                        );
                      }
                      $feature_onbuys = array_merge($feature_onbuys, $feature_onbuy);
                  }
              } else {
                $response = $this->getVariantData($onbuy_attribute_id, $mapped_options['default_values'], $category_id);
                $feature_onbuy[] = array(
                  'option_id' =>(int) $response['option_id'], 
                  'name' => $mapped_options['default_values'],
                  'hex' => isset($response['hex']) ? $response['hex'] : ''
                );
              }
              //$feature_onbuys = array_merge($feature_onbuys, $feature_onbuy);
          }
          
        }
        $feature_onbuys = array_filter($feature_onbuys);
        return $feature_onbuys;
      } else {
        return array();
      }
    }

    public function getVariantData($feature_id, $variant_name, $category_id, $variant_key = 'feature')
    {
      $response = array();
      if($variant_name && $category_id)
      {
        $sql = $this->db->query("SELECT `options` FROM `". DB_PREFIX ."cedonbuy_variants` WHERE `feature_id` = '". (int) $feature_id."' AND `variant_key` = '". $this->db->escape($variant_key) ."' AND `category_id` = '". (int) $category_id."' ");
        if($sql->num_rows)
        {
          $options = json_decode($sql->row['options'], true);
          foreach($options as $option)
          {
            if($option['name'] == $variant_name)
            {
              $response = array(
                'option_id' => $option['option_id'],
                'hex' => (isset($option['hex']) && !empty($option['hex'])) ? $option['hex'] : ''
                );
            }
          }
        }
      }
      return $response;
    }

    public function getProductListing($product, $condition)
    {
      $listing_array = array();
      if(isset($product) && is_array($product) && $product)
      {
        $sku = '';
        if(!empty($product['sku']))
          $sku = $product['sku'] . '-' . strtoupper($condition);
        $listing_array[$condition] = array(
          'sku' => $sku,
          'group_sku' => !empty($product['model']) ? $product['model'] : '',
          'price' => (float) $product['price'],
          'stock' => (int)  $product['quantity'],
          );
      }
      return $listing_array;
    }

    public function getOnbuyProductPrice($product_id)
    {
        if($product_id) {
            $onbuy_price = 0;
            $price_variation_type = $this->config->get('ced_onbuy_product_price');
            if(!empty($this->config->get('ced_onbuy_product_price_fixed')))
                $price_variation_type_ampount =(float) $this->config->get('ced_onbuy_product_price_fixed');
            else
                $price_variation_type_ampount =(float) $this->config->get('ced_onbuy_product_price_percentage');

            switch ($price_variation_type) {
                case '1':   // regular
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $onbuy_price = $price;
                    break;

                case 'special':
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product_special WHERE product_id = '" . (int)$product_id . "' AND ((date_start = '0000-00-00' OR date_start < NOW()) AND (date_end = '0000-00-00' OR date_end > NOW())) ORDER BY priority ASC, price ASC");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $onbuy_price = $price;
                    break;

                case '2':   // increase_by_amount
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $onbuy_price = $price + $price_variation_type_ampount;
                    break;

                case '3':  // decrease_by_amount
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $onbuy_price = $price - $price_variation_type_ampount;
                    break;

                case '4':  // increase_by_percent
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $onbuy_price = $price + ($price * $price_variation_type_ampount)/100;
                    break;

                case '5':   // decrease_by_percent
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $onbuy_price = $price - ($price * $price_variation_type_ampount)/100;
                    break;

                default:
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $onbuy_price = $price;
                    break;
            }
            return $onbuy_price ;
        }
        return 0;
    }

    public function isVariantProduct($product_id, $product)
    {
      $attirbute_combination = array();
      $product_option_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_option` po LEFT JOIN `" . DB_PREFIX . "option` o ON (po.option_id = o.option_id) LEFT JOIN `" . DB_PREFIX . "option_description` od ON (o.option_id = od.option_id) WHERE po.product_id = '" . (int)$product_id . "' AND od.language_id = '" . (int)$this->config->get('config_language_id') . "' AND o.type IN ('select','radio','checkbox')");

      //echo '<pre>'; print_r($product_option_query); die;
        if ($product_option_query && $product_option_query->num_rows) 
        {
            foreach ($product_option_query->rows as $option) 
            {
                $product_option_value_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_option_value` pov LEFT JOIN `".DB_PREFIX."option_value_description` ovd ON (pov.option_value_id=ovd.option_value_id) WHERE pov.product_id = '" . (int)$product_id . "' AND ovd.language_id = '" . (int)$this->config->get('config_language_id') . "'");
                if($product_option_value_query && $product_option_value_query->num_rows) 
                {
                  $attirbute_combination_variant = array();
                    foreach ($product_option_value_query->rows as $option_value) {
                        if(isset($option_value['product_option_value_id']) && isset($option_value['product_option_id']) && isset($option_value['option_id']) && isset($option_value['option_value_id']))
                        {
                            $attirbute_combination[$option_value['product_option_id']][$option_value['product_option_value_id']] = $option_value['product_option_value_id'];

                            $variant_sku = $product_id.'-'.$option_value['product_option_id'].'-'.$option_value['option_id'].'-'.$option_value['product_option_value_id'];
                            $variant_qty = $option_value['quantity'];
                            $price = $option_value['price'];
                            $price_prefix = $option_value['price_prefix'];
                            $variant_price = $this->calculateValueByPrefix($product['price'], $price, $price_prefix);
                            $name = $option_value['name'];
                            $attirbute_combination_variant[$option_value['product_option_value_id']] = array(
                                //'name' => (string)$name,
                                'stock' => (int)$variant_qty,
                                'price' => (float)$variant_price,
                                'sku' => (string)$variant_sku,
                            );
                        }
                    }
                }
            }
        }
        $variations = array();
        if(count(array_values($attirbute_combination))>1)
            $attirbute_combination_options = $this->combinations(array_values($attirbute_combination));
        else
            $attirbute_combination_options = isset($attirbute_combination_variant) ? array($attirbute_combination_variant) : '';

        if(!empty($attirbute_combination_options) && (count($attirbute_combination_options)>1)) 
        {
            foreach ($attirbute_combination_options as $attirbute_combination_option) {
                $name = '';
                $qty = array();
                $price = array();
                $sku = '';
                foreach ($attirbute_combination_option as $attirbute_combination_opt) {

                    if(isset($attirbute_combination_variant[$attirbute_combination_opt]) && $attirbute_combination_variant[$attirbute_combination_opt]){
                        $attirbute_combination_variant[$attirbute_combination_opt];
                        $name .= $attirbute_combination_variant[$attirbute_combination_opt]['name'].' ';
                        $qty[] = $attirbute_combination_variant[$attirbute_combination_opt]['stock'];
                        $price[] = $attirbute_combination_variant[$attirbute_combination_opt]['price'];
                        $sku .= $attirbute_combination_variant[$attirbute_combination_opt]['variation_sku'].'sku'.$attirbute_combination_opt;
                    }

                }
                $product_option_value_query = $this->db->query("SELECT id, variation_id FROM `" . DB_PREFIX . "cedonbuy_product_variations` where variation_sku = '".$sku."' AND product_id='".$product_id."'");
                if( $product_option_value_query  &&  $product_option_value_query ->num_rows && isset($product_option_value_query ->row['variation_id']) && $product_option_value_query ->row['variation_id']) {
                    $variations[] = array(
                        'stock' => (int)min($qty),
                        'price' => (float)$product['price']+max($price),
                        'variation_sku' => (string)$sku,
                        'variation_id' => (int) $product_option_value_query ->row['variation_id'],
                    );
                } else {
                    $variations[] = array(
                        'stock' => (int)min($qty),
                        'price' => (float)$product['price']+max($price),
                        'sku' => (string)$sku,
                    );
                }

            }
        } else {
            if(isset($attirbute_combination_options[0])) {
                foreach ($attirbute_combination_options[0] as $attirbute_combination_option) {

                    $sku = $attirbute_combination_option['variation_sku'];
                    $product_option_value_query = $this->db->query("SELECT id, variation_id FROM `" . DB_PREFIX . "cedonbuy_product_variations` where variation_sku = '".$sku."' AND product_id='".$product_id."'");
                    if( $product_option_value_query  &&  $product_option_value_query ->num_rows && isset($product_option_value_query ->row['variation_id']) && $product_option_value_query ->row['variation_id']) {
                        $variations[] = array(
                            //'name' => (string)trim($attirbute_combination_option['name']),
                            'stock' => (int)$attirbute_combination_option['stock'],
                            'price' => (float)$product['price']+$attirbute_combination_option['price'],
                            'sku' => (string)$attirbute_combination_option['variation_sku'],
                            //'variation_id' => (int) $product_option_value_query ->row['variation_id'],
                        );
                    } else {
                        $variations[] = array(
                            //'name' => (string)trim($attirbute_combination_option['name']),
                            'stock' => (int)$product['stock'] + $attirbute_combination_option['stock'],
                            'price' => (float)$product['price']+$attirbute_combination_option['price'],
                            'sku' => (string)$attirbute_combination_option['variation_sku'],
                        );
                    }

                }
            }
        }
        return $variations;
    }

    public function calculateValueByPrefix($original_value, $value, $prefix) {
        switch ($prefix) {
            case '+' :
                return (float)$original_value + (float)$value;
                break;
            case '-' :
                return (float)$original_value - (float)$value;
                break;
            default :
                return $original_value;
                break;
        }
    }

    public function combinations($arrays, $i = 0) {
        if (!isset($arrays[$i])) {
            return array();
        }
        if ($i == count($arrays) - 1) {
            return $arrays[$i];
        }
        $tmp = $this->combinations($arrays, $i + 1);

        $result = array();
        foreach ($arrays[$i] as $v) {
            foreach ($tmp as $t) {
                $result[] = is_array($t) ?
                    array_merge(array($v), $t) :
                    array($v, $t);
            }
        }
        return $result;
    }

    public function fetchOrders($offset = 0)
    {
      $access_token = $this->config->get('ced_onbuy_access_token');
      $access_token_expiry = $this->config->get('ced_onbuy_expires_at');
      $now = strtotime(date('Y-m-d h:i:s a'));
      
      if(!empty($access_token) && !empty($access_token_expiry) && $access_token_expiry > $now)
      {
        $this->updateAccessToken();
      }
      $path = 'orders';
      $createdStartDate = date('Y-m-d H:i:s');
      $params = array(
        'site_id' => $this->config->get('ced_onbuy_site_id'),
        'limit' => '100',
        'offset' => $offset,
        'filter' => array(
          'modified_since' => $createdStartDate,
          'status' => 'all',
          'order_ids' => ''
        ),
        'sort' => array(
          'created' => 'desc'
        )
      );
        
      $response = $this->getRequest($path, $params);

      $this->log($response);
      try {
        $errorMessage= '';
        if ($response) {
          if (isset($response['status']) && $response['status'] == true) 
          {
              if (isset($response['response']) && $response['response']) 
              {
                $response = $response['response'];
                $data = $response['results'];
                $total_rows = count($response['results']);

                if (!is_array($data)) {
                    return array('success' => false ,'message' => $response);
                }
                $errorMessage = '';
                if (!isset($data) && empty($data)) 
                {
                  $errorMessage  =  $response;
                  // foreach ($response['errors'] as $key => $error)
                  // {
                  //    foreach ($error as $key => $err) {
                  //       if (isset($err['description']) && $err['  description']) {
                  //           $errorMessage .= $err['description'];
                  //       }
                  //     }
                  // }
                } else {
                  $order_ids = array();
                  if (is_array($data) && isset($data))
                  {
                    $fetchedOrders = $data;

                    if (is_array($fetchedOrders) && isset($fetchedOrders) && count($fetchedOrders)) {

                      if(!isset($fetchedOrders['0']))
                      {
                          $temp_orderLine = $fetchedOrders;
                          $fetchedOrders = array();
                          $fetchedOrders['0'] = $temp_orderLine;
                      }
                      $totalOrderFetched = count($fetchedOrders);

                      foreach ($fetchedOrders as $key => $value) 
                      {
                        if (isset($value['order_id']) && $value['order_id']) 
                        {
                          $onbuy_order_id = $value['order_id'];
                          $already_exist = $this->isOnbuyOrderIdExist($onbuy_order_id, $value);

                          if( $already_exist ) {
                            continue;
                          } else {
                            $order_ids[] = $this->prepareOrderData($value);
                            $this->log(json_encode($value),'6',true);
                            $order_ids = array_filter($order_ids);
                          }
                        }
                      }

                      if($total_rows >= '100')
                      {
                        $noOfOrdersToSkip = $offset + '100';
                        $this->fetchOrders($noOfOrdersToSkip);
                      }

                      if (count($order_ids) == $totalOrderFetched) 
                      {
                        return array('success' => true ,'message' => implode(',', $order_ids) . ' Orders Fetched Successfully!');
                      } else if(count($order_ids) && ($totalOrderFetched > count($order_ids))) {
                        return array('success' => true ,'message' => $order_ids,'sub_message' => 'Please see rejected list too.');
                      } else if(count($order_ids)==0) {
                        return array('success' => true ,'message' => 'No new Order Found.');
                      } else {
                        return array('success' => false ,'message' => 'Order Send to Rejected List.');
                      }
                    } else {
                      return array('success' => true ,'message' => 'No new order found.');
                    }
                  }
                }
              }
              if ($errorMessage) {
                  return array('success' => false ,'message' => $errorMessage);
              }
          } else {
            return array('success' => false ,'message' => $response['message']);
          }
        } else {
            return array('success' => false ,'message' =>$this->language->get('error_module'));
        }
      }
      catch(Exception $e) {
          $this->log('Order Error:  ' . var_export($response, true));
          $this->log('Order Error Message : ' .$e->getMessage());
          return array('success' => false ,'message' => $e->getMessage());
      }
    }

    public function isOnbuyOrderIdExist($onbuy_order_id=0, $orderData = array())
    {
        $isExist = false ;
        if ($onbuy_order_id) {
            $sql = "SELECT `id` FROM `" . DB_PREFIX . "cedonbuy_order` WHERE `onbuy_order_id` = '".$onbuy_order_id."' ";

            $result = $this->db->query($sql);

            if ($result->num_rows) {
                $orderStatus = $orderData['status'];
                if(isset($orderData) && is_array($orderData) && $orderData)
                {
                  $orderLine = $orderData;

                  if($orderStatus == 'Partially Dispatched')
                      $orderStatus = 'Processing';
                  elseif($orderStatus == 'open')
                      $orderStatus = 'Processing';
                  elseif($orderStatus == 'awaiting_dispatch')
                      $orderStatus = 'Processing';
                  elseif($orderStatus == 'dispatched')
                      $orderStatus = 'Shipped';
                  elseif($orderStatus == 'complete')
                      $orderStatus = 'Complete';
                    elseif($orderStatus == 'cancelled')
                      $orderStatus = 'Cancelled';
                    elseif($orderStatus == 'cancelled_by_seller')
                      $orderStatus = 'Cancelled';
                    elseif($orderStatus == 'cancelled_by_buyer')
                      $orderStatus = 'Cancelled';
                    elseif($orderStatus == 'refunded')
                      $orderStatus = 'Refunded';
                  else
                      $orderStatus = $orderStatus;
                }
                $this->updateOrderStatus($onbuy_order_id, $orderStatus);
                
                $this->updateOnbuyOrderData($onbuy_order_id, $orderData['status'], $orderData);
                $isExist = true ;
            }
        }
        return $isExist;
    }

    public function prepareOrderData( $data = array()) 
    {
      if ($data) {
          $opencart_order_id = 0;
          $onbuy_order_id = $data['order_id'];

          if (!$this->isOnbuyOrderIdExist($onbuy_order_id, $data)) 
          {
            $id = $this->createOnbuyOrder($data);
            if($id)
              return $id;
          }
      }
    }

    public function createOnbuyOrder($data) 
    {
      $order_data   = array();
        
      $customerOrderId      = isset($data['onbuy_internal_reference']) ? $data['onbuy_internal_reference'] : '';
      $orderId              = $data['order_id'];
      $orderDate            = $data['date'];

      if(!empty($this->config->get('ced_onbuy_order_status')))
      {
          $sql = $this->db->query("SELECT `name` FROM `". DB_PREFIX."order_status` WHERE order_status_id = '". (int) $this->config->get('ced_onbuy_order_status') ."' AND language_id = '". $this->config->get('ced_onbuy_store_language') ."' ");
          $res = $sql->row['name'];
          $orderStatus = $res;
      } else {
          $orderStatus = $data['status'];

          if($orderStatus == 'Partially Dispatched')
              $orderStatus = 'Processing';
          elseif($orderStatus == 'open')
              $orderStatus = 'Processing';
          elseif($orderStatus == 'awaiting_dispatch')
              $orderStatus = 'Processing';
          elseif($orderStatus == 'dispatched')
              $orderStatus = 'Shipped';
          elseif($orderStatus == 'complete')
              $orderStatus = 'Complete';
            elseif($orderStatus == 'cancelled')
              $orderStatus = 'Cancelled';
            elseif($orderStatus == 'cancelled_by_seller')
              $orderStatus = 'Cancelled';
            elseif($orderStatus == 'cancelled_by_buyer')
              $orderStatus = 'Cancelled';
            elseif($orderStatus == 'refunded')
              $orderStatus = 'Refunded';
          else
              $orderStatus = $orderStatus;
      }

      if(isset($data['buyer']) && $data['buyer'])
      {
          $buyer = $data['buyer'];

          $name = explode(' ', $buyer['name']);
          $firstName    = $name[0];
          @$lastName     = $name[1];
          $phoneNumber  = $buyer['phone'];

          if(isset($buyer['email']) && $buyer['email'])
            $email = $buyer['email'];
          else if(!empty($this->config->get('ced_onbuy_default_customer_email')))
            $email = $this->config->get('ced_onbuy_default_customer_email');
          else
            $email = $orderId.'@cedonbuycustomer.com';
      }

      if(isset($data['billing_address']) && $data['billing_address'])
      {
        $billing_address = $data['billing_address'];

        $name = explode(' ', $billing_address['name']);
        $payment_firstName    = $name[0];
        @$payment_lastName     = $name[1];

        $address = '';
        if(!empty($billing_address['line_1']))
          $address = $billing_address['line_1'];
        else if(!empty($billing_address['line_2']))
          $address .= ' ' . $billing_address['line_2'];
        else if(!empty($billing_address['line_3']))
          $address .= ' ' . $billing_address['line_3'];

        $payment_streetAddress = $address;
        $payment_city         = $billing_address['town'];
        $payment_postalCode   = $billing_address['postcode'];
        $payment_countryCode  = $billing_address['country_code'];
        $payment_country      = $billing_address['country'];
      }

      if(isset($data['delivery_address']) && $data['delivery_address'])
      {
        $delivery_address = $data['delivery_address'];

        $name = explode(' ', $delivery_address['name']);
        $shipping_firstName    = $name[0];
        @$shipping_lastName     = $name[1];

        $address = '';
        if(!empty($delivery_address['line_1']))
          $address = $delivery_address['line_1'];
        else if(!empty($delivery_address['line_2']))
          $address .= ' ' . $delivery_address['line_2'];
        else if(!empty($delivery_address['line_3']))
          $address .= ' ' . $delivery_address['line_3'];

        $shipping_streetAddress= $address;
        $shipping_city         = $delivery_address['town'];
        $shipping_postalCode   = $delivery_address['postcode'];
        $shipping_countryCode  = $delivery_address['country_code'];
        $shipping_country      = $delivery_address['country'];
      }
      
      if(!empty($this->config->get('ced_onbuy_order_carrier'))){
          $res = $this->getExtensionsById('shipping', $this->config->get('ced_onbuy_order_carrier'));
          $shippingMethod      = $res['code'];
      } else {
          $delivery_template = $this->getDeliveryTemplate($data['delivery_tag']);
          $shippingMethod      = $delivery_template . ' - ' . $data['delivery_tag'];
      }

      $currencyCode       = (isset($data['currency_code']) && !empty($data['currency_code'])) ? $data['currency_code'] : '';

        // Order Array
        $order_data['invoice_prefix']     = $this->config->get('config_invoice_prefix');
        $order_data['store_id']           = $this->config->get('config_store_id');
        $order_data['store_name']         = $this->config->get('config_name');
        $order_data['store_url']          = HTTPS_SERVER;
        $order_data['customer_id']        = $customerOrderId;
        $order_data['customer_group_id']  = '1';
        $order_data['firstname']          = $firstName;
        $order_data['lastname']           = $lastName;
        $order_data['email']              = $email;
        $order_data['telephone']          = $phoneNumber;
        $order_data['fax']                = '';
        $order_data['order_status']       = $orderStatus;
        $order_data['custom_field']       = array();

        // Payment Detail
        $order_data['payment_firstname']  = $payment_firstName;
        $order_data['payment_lastname']   = $payment_lastName;
        $order_data['payment_company']    = '';
        $order_data['payment_address_1']  = $payment_streetAddress;
        $order_data['payment_address_2']  = '';
        $order_data['payment_city']       = $payment_city;
        $order_data['payment_postcode']   = $payment_postalCode;
        $order_data['payment_zone']       = '';
        $order_data['payment_zone_id']    = '0';
        $country_info = $this->getOpencartCountryByOnbuyCountryCode($payment_countryCode);
        $order_data['payment_country']    = !empty($payment_country) ?  $payment_country : $country_info['country'];
        $order_data['payment_country_id'] = isset($country_info['country_id']) ? $country_info['country_id'] : '0';
        $order_data['payment_address_format'] = '';
        $order_data['payment_custom_field']   = array();
        $payment_method_id = $this->config->get('ced_onbuy_order_payment');
        $paymentInfo = $this->getExtensionsById('payment', $payment_method_id);
        $order_data['payment_method']         = isset($paymentInfo['code']) ? $paymentInfo['code'] : 'Onbuy Payment';
        $order_data['payment_code']           = 'OnbuyPayment';
        $order_data['payment_language']       = '';
        $order_data['payment_language_id']    = '0';
        $currency_info = $this->getOpencartCurrencyByOnbuyCurrencyCode($currencyCode);
        $order_data['payment_currency']        = isset($currencyCode) ? $currencyCode : '';
        $order_data['payment_currency_id']     = isset($currency_info['currency_id']) ? $currency_info['currency_id'] : '0';

        // Shipping Detail
        $order_data['shipping_firstname']         = $shipping_firstName;
        $order_data['shipping_lastname']          = $shipping_lastName;
        $order_data['shipping_company']           = '';
        $order_data['shipping_address_1']         = $shipping_streetAddress;
        $order_data['shipping_address_2']         = '';
        $order_data['shipping_city']              = $shipping_city;
        $order_data['shipping_postcode']          = $shipping_postalCode;
        $order_data['shipping_zone']              = '';
        $order_data['shipping_zone_id']           = '0';
        $country_info = $this->getOpencartCountryByOnbuyCountryCode($shipping_countryCode);
        $order_data['shipping_country']           = !empty($shipping_country) ?  $shipping_country : $country_info['country'];
        $order_data['shipping_country_id']        = isset($country_info['country_id']) ? $country_info['country_id'] : '0';
        $order_data['shipping_address_format']    = '';
        $order_data['shipping_custom_field']      = array();
        $order_data['shipping_method']            = isset($shippingMethod) ? $shippingMethod : 'Onbuy Shipping';
        $order_data['shipping_code']              = 'OnbuyShipping.OnbuyShipping';

        // for products
        $total_price = isset($data['price_total']) ? $data['price_total'] : 0;
        $total_shipping_cost = isset($data['price_delivery']) ? $data['price_delivery'] : 0;
        $subtotal = isset($data['price_subtotal']) ? $data['price_subtotal'] : 0;
        //$discount_amt = isset($data['discount_amt']) ? $data['discount_amt'] : 0;
        $grandtotal = '0';

        $order_items  = $data['products'];
        //$grand_total = '0';
        if($order_items && count($order_items))
        {
            if(!isset($order_items['0']))
            {
                $temp_results = $order_items;
                $order_items = array();
                $order_items['0'] = $temp_results;
            }

            $final_item_cost = 0;
            foreach($order_items as $key => $item)
            {
                $item_cost = isset($item['unit_price']) ? (float)$item['unit_price'] : 0;
                $qty = isset($item['quantity']) ? $item['quantity'] : '0';
                $opc = isset($item['opc']) ? $item['opc'] : '';
                $product_id = $this->getProductIdByOpc($opc);

                $ordered_products = $this->getOpencartProductBySku($product_id, $item['sku'], $qty, $item, $orderId, $item['name'], $item_cost, '0');
                
                $total_cost = $item_cost * (int)$qty;
                $final_item_cost += (float)$total_cost;
                
                if($ordered_products)
                    $order_data['products'][] = $ordered_products;
            }
        }

        $grandtotal += $final_item_cost;

        if(isset($order_data['products']) && count($order_data['products'])>0)
        {
            $order_data['vouchers']=array();

            $order_data['totals'][]= array(
                'code' => 'sub_total',
                'title' => 'Sub-Total',
                'value'=> $subtotal,
                'sort_order' => 1
            );

            $order_data['totals'][]= array(
                'code' => 'shipping',
                'title' => 'Onbuy Shipping',
                'value'=>(float) $total_shipping_cost,
                'sort_order' => 3
            );

            $order_data['totals'][]= array(
                'code' => 'total',
                'title' => 'Total',
                'value'=> (float) $grandtotal+$total_shipping_cost,
                'sort_order' => 9
            );

            $order_data['comment']='';
            $order_data['total']= (float) $grandtotal+$total_shipping_cost;
            $order_data['affiliate_id']='0';
            $order_data['commission']='0';
            $order_data['marketing_id']='0';
            $order_data['tracking']='';
            $order_data['language_id'] = $this->config->get('ced_onbuy_store_language');

            if(isset($currency_info['currency_id']) && !empty($currency_info['currency_id']) && isset($currency_info['value']) && !empty($currency_info['value']))
             {
                $order_data['currency_id'] = $currency_info['currency_id'];
                $order_data['currency_code'] = $currencyCode;
                $order_data['currency_value'] = $currency_info['value'];
            } elseif (isset($this->session->data['currency']) && $this->session->data['currency']) {
                 $order_data['currency_id'] = $this->currency->getId($this->session->data['currency']);
                 $order_data['currency_code'] = $this->session->data['currency'];
                 $order_data['currency_value'] = $this->currency->getValue($this->session->data['currency']);
             }

            if($order_data['currency_value'] == 0)
                $order_data['currency_value'] = '1';

            $order_data['ip'] = '';
            $order_data['forwarded_ip'] = '';
            $order_data['user_agent'] = '';
            $order_data['accept_language'] = '';

            $query = $this->db->query("SELECT `id` FROM " . DB_PREFIX . "cedonbuy_order WHERE onbuy_order_id='".$orderId."' ");
            if($query->num_rows){
              $this->updateOrderStatus($orderId, $orderStatus);
              $respo = $this->updateOnbuyOrderData($orderId, $data['status'], $data);
            } else {
              $opencart_order_id = $this->addOnbuyOrder($order_data);
              $respo = $this->db->query("INSERT INTO " . DB_PREFIX . "cedonbuy_order SET opencart_order_id =  '" . (int)$opencart_order_id . "', onbuy_order_id='". $this->db->escape($orderId) ."', onbuy_status = '". $this->db->escape(strtoupper($data['status'])) ."', order_data = '".$this->db->escape(json_encode($data))."', `order_place_date` = '" . $this->db->escape($orderDate) . "' ");
            }

            if($respo){
                $order_ids[] = $opencart_order_id;
            }
        } else {
            $this->session->data['success'] = "Onbuy Order not imported, please see rejected list";
        }

        if (!empty($opencart_order_id)) {
            return $opencart_order_id;
        }
        return false;
    }

    public function getDeliveryTemplate($delivery_tag = '')
    {
      if($delivery_tag)
      {
        $sql = $this->db->query("SELECT `template_name` FROM `". DB_PREFIX ."cedonbuy_logistics` WHERE `delivery_tag` = '". $this->db->escape($delivery_tag) ."' ");
        return $sql->row['template_name'];
      } else {
        return null;
      }
    }

    public function getOpencartZoneByOnbuyZoneCode($state_name)
    {
        $query=$this->db->query("SELECT `zone_id` FROM " . DB_PREFIX . "zone WHERE name='".$state_name."'");
        if($query->num_rows)
        {
            return $query->row;
        } else {
            return array();
        }
    }

    public function getOpencartCountryByOnbuyCountryCode($onbuy_country_code)
    {
        $query=$this->db->query("SELECT country_id, name FROM " . DB_PREFIX . "country WHERE iso_code_2 ='".$onbuy_country_code."'");
        if($query->num_rows)
        {
            return $query->row;
        } else {
            return array();
        }
    }

    public function getOpencartLanguageByOnbuyLanguageCode($onbuy_language_code)
    {
        $query=$this->db->query("SELECT language_id, name FROM " . DB_PREFIX . "language WHERE code ='".$onbuy_language_code."'");
        if($query->num_rows)
        {
            return $query->row;
        } else {
            return array();
        }
    }

    public function getOpencartCurrencyByOnbuyCurrencyCode($onbuy_currency_code)
    {
      //echo $onbuy_currency_code; die;
        $query=$this->db->query("SELECT currency_id, value FROM " . DB_PREFIX . "currency WHERE code = '".$onbuy_currency_code."'");
        if($query->num_rows)
        {
            return $query->row;
        } else {
            return array();
        }

    }

    public function getExtensions($type) 
    {
      $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "extension WHERE `type` = '" . $this->db->escape($type) . "'");

      return $query->rows;
    }

    public function getExtensionsById($type, $extension_id)
    {
        $query = $this->db->query("SELECT code FROM " . DB_PREFIX . "extension WHERE `type` = '" . $this->db->escape($type) . "' AND extension_id = '". $extension_id ."' ");
        return $query->row;
    }

    public function getProductIdByOpc($opc = '')
    {
      if($opc)
      {
        $sql = $this->db->query("SELECT `product_id` FROM `". DB_PREFIX ."cedonbuy_profile_products` WHERE `opc` = '". $this->db->escape($opc) ."' ");
        if($sql->num_rows)
          return $sql->row['product_id'];
        else
          return null;
      } else {
        return null;
      }
    }

    public function getOpencartProductBySku($product_id, $sku, $quantity, $order_data, $onbuy_order_id, $product_title, $onbuy_price, $totalVat)
    {
        $product=array();
        $sql = "SELECT `status`,`minimum`,`quantity`,`model`,`price`FROM `".DB_PREFIX ."product` WHERE product_id = '". (int) $product_id."' ";
        $query = $this->db->query($sql);

        if($query->num_rows)
        {
            $result = $this->db->query("SELECT `combination` FROM `" . DB_PREFIX . "cedonbuy_product_attribute_combination` WHERE `SkuId`='".$sku."' AND `product_id` = '". (int) $product_id ."' ");
            
            $combination=isset($result->row['combination'])?$result->row['combination']:'{}';

            $status     =$query->row['status'];
            $minimum    =$query->row['minimum'];
            $qty_avail  =$query->row['quantity'];
            $model      =$query->row['model'];
            $price      =$query->row['price'];

            if($status)
            {
                if($qty_avail >= $quantity)
                {
                    $product['quantity']  = $quantity;
                    $product['product_id']= $product_id;
                    $product['model']     = $model;
                    $product['subtract']  = $quantity;
                    $product['price']     = ($onbuy_price) ? $onbuy_price : $price;
                    $product['total']     = ($onbuy_price) ? $quantity * $onbuy_price : $quantity * $price;
                    $product['tax']       = ($totalVat) ? $totalVat : '0';
                    $product['reward']    = 0;
                    $product['name']      = $product_title;
                    $product['option']    = json_decode($combination,true);
                    $product['download']  = array();
                    return $product;
                } else {
                    $this->addOrderErrorInfo($onbuy_order_id, $order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku, $quantity);
                    return '0';
                }
            } else {
                $this->addOrderErrorInfo($onbuy_order_id, $order_data,"PRODUCT STATUS IS DISABLED WITH ID ".$product_id, $sku, $quantity);
                return '0';
            }
        } else {
            $sql = "SELECT `product_id`, `status`, `minimum`, `quantity`, `model`, `price` FROM `" . DB_PREFIX . "product` WHERE `sku` = '".$sku."'";
            $product_data = $query = $this->db->query($sql);

            if($product_data && $product_data->num_rows && isset($product_data->row['product_id']))
            {
                $product_id = $product_data->row['product_id'];
                $status     = $product_data->row['status'];
                $minimum    = $product_data->row['minimum'];
                $qty_avail  = $product_data->row['quantity'];
                $model      = $product_data->row['model'];
                $price      = $product_data->row['price'];
                if($status)
                {
                    if($qty_avail >= $quantity)
                    {
                        $product['quantity']  = $quantity;
                        $product['product_id']= $product_id;
                        $product['model']     = $model;
                        $product['subtract']  = $quantity;
                        $product['price']     = ($onbuy_price) ? $onbuy_price : $price;
                        $product['total']     = ($onbuy_price) ? $quantity * $onbuy_price : $quantity * $price;
                        $product['tax']       = ($totalVat) ? $totalVat : '0';
                        $product['reward']    = 0;
                        $product['name']      = $product_title;
                        $product['option']    = array();
                        $product['download']  = array();
                        return $product;
                    } else {
                        $this->addOrderErrorInfo($onbuy_order_id, $order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku, $quantity);
                        return '0';
                    }
                } else {
                    $this->addOrderErrorInfo($onbuy_order_id, $order_data,"PRODUCT STATUS IS DISABLED WITH ID ".$product_id, $sku, $quantity);
                    return '0';
                }
            } else {
                $this->addOrderErrorInfo($onbuy_order_id, $order_data,"MERCHANT SKU OR PRODUCT DOES NOT EXIST", $sku, $quantity);
                return '0';
            }
        }
    }
    public function addOrderErrorInfo($onbuy_order_id, $order_data, $error_message, $sku, $quantity)
    {
        $already_exists = $this->db->query("SELECT * FROM `" . DB_PREFIX . "cedonbuy_order_error` WHERE `sku` = '" . $sku . "' AND onbuy_order_id = '" . $onbuy_order_id . "' ");

        if($already_exists->num_rows == 0)
        {
            $sql = " INSERT INTO `" . DB_PREFIX . "cedonbuy_order_error` (`sku`, `onbuy_order_id`, `order_data`, `reason`, `cancel_qty`)VALUES('" . $sku . "', '" . $onbuy_order_id . "', '" . $this->db->escape(json_encode($order_data)) . "', '" . $error_message . "', '". (int) $quantity ."')";
            $result=$this->db->query($sql);

            if($result)
            {
              return $onbuy_order_id;
            }
        }
    }

    public function getOrderStatusIdByName($name)
    {
        $sql ="SELECT `order_status_id` FROM `".DB_PREFIX."order_status` WHERE `name`='".$name."'";
        $query=$this->db->query($sql);
        if($query && $query->num_rows)
            return $query->row['order_status_id'];
    }

    public function updateOrderStatus($onbuyOrderId, $orderStatus = '')
    {
      $result = $this->db->query("SELECT `opencart_order_id` FROM `" . DB_PREFIX . "cedonbuy_order` WHERE `onbuy_order_id` = '" . (int)$onbuyOrderId . "'");

      if($result->num_rows)
      {
        $order_id = $result->row['opencart_order_id'];

        $order_status_id = $this->getOrderStatusIdByName($orderStatus);
        $this->db->query("UPDATE `" . DB_PREFIX . "order` SET order_status_id = '". $order_status_id ."' WHERE order_id = '".$order_id."' ");
        $this->db->query("UPDATE `" . DB_PREFIX . "order_history` SET order_status_id = '". $order_status_id ."' WHERE order_id = '".$order_id."' ");
      }
    }

    public function updateOnbuyOrderData($onbuyOrderId, $status, $data)
    {
        $this->db->query(" UPDATE `" . DB_PREFIX . "cedonbuy_order` SET `onbuy_status` = '". $this->db->escape(strtoupper($status)) ."' , `order_data` = '". $this->db->escape(json_encode($data)) ."' WHERE `onbuy_order_id` = '". $this->db->escape($onbuyOrderId) ."' ");
    }

    public function addOnbuyOrder($data)
    {
      $this->db->query("INSERT INTO `" . DB_PREFIX . "order` SET invoice_prefix = '" . $this->db->escape($data['invoice_prefix']) . "', store_id = '" . (int)$data['store_id'] . "', store_name = '" . $this->db->escape($data['store_name']) . "', store_url = '" . $this->db->escape($data['store_url']) . "', customer_id = '" . (int)$data['customer_id'] . "', customer_group_id = '" . (int)$data['customer_group_id'] . "', firstname = '" . $this->db->escape($data['firstname']) . "', lastname = '" . $this->db->escape($data['lastname']) . "', email = '" . $this->db->escape($data['email']) . "', telephone = '" . $this->db->escape($data['telephone']) . "', fax = '" . $this->db->escape($data['fax']) . "', custom_field = '" . $this->db->escape(isset($data['custom_field']) ? serialize($data['custom_field']) : '') . "', payment_firstname = '" . $this->db->escape($data['payment_firstname']) . "', payment_lastname = '" . $this->db->escape($data['payment_lastname']) . "', payment_company = '" . $this->db->escape($data['payment_company']) . "', payment_address_1 = '" . $this->db->escape($data['payment_address_1']) . "', payment_address_2 = '" . $this->db->escape($data['payment_address_2']) . "', payment_city = '" . $this->db->escape($data['payment_city']) . "', payment_postcode = '" . $this->db->escape($data['payment_postcode']) . "', payment_country = '" . $this->db->escape($data['payment_country']) . "', payment_country_id = '" . (int)$data['payment_country_id'] . "', payment_zone = '" . $this->db->escape($data['payment_zone']) . "', payment_zone_id = '" . (int)$data['payment_zone_id'] . "', payment_address_format = '" . $this->db->escape($data['payment_address_format']) . "', payment_custom_field = '" . $this->db->escape(isset($data['payment_custom_field']) ? serialize($data['payment_custom_field']) : '') . "', payment_method = '" . $this->db->escape($data['payment_method']) . "', payment_code = '" . $this->db->escape($data['payment_code']) . "', shipping_firstname = '" . $this->db->escape($data['shipping_firstname']) . "', shipping_lastname = '" . $this->db->escape($data['shipping_lastname']) . "', shipping_company = '" . $this->db->escape($data['shipping_company']) . "', shipping_address_1 = '" . $this->db->escape($data['shipping_address_1']) . "', shipping_address_2 = '" . $this->db->escape($data['shipping_address_2']) . "', shipping_city = '" . $this->db->escape($data['shipping_city']) . "', shipping_postcode = '" . $this->db->escape($data['shipping_postcode']) . "', shipping_country = '" . $this->db->escape($data['shipping_country']) . "', shipping_country_id = '" . (int)$data['shipping_country_id'] . "', shipping_zone = '" . $this->db->escape($data['shipping_zone']) . "', shipping_zone_id = '" . (int)$data['shipping_zone_id'] . "', shipping_address_format = '" . $this->db->escape($data['shipping_address_format']) . "', shipping_custom_field = '" . $this->db->escape(isset($data['shipping_custom_field']) ? serialize($data['shipping_custom_field']) : '') . "', shipping_method = '" . $this->db->escape($data['shipping_method']) . "', shipping_code = '" . $this->db->escape($data['shipping_code']) . "', comment = '" . $this->db->escape($data['comment']) . "', total = '" . (float)$data['total'] . "', affiliate_id = '" . (int)$data['affiliate_id'] . "', commission = '" . (float)$data['commission'] . "', marketing_id = '" . (int)$data['marketing_id'] . "', tracking = '" . $this->db->escape($data['tracking']) . "', language_id = '" . (int)$data['language_id'] . "', currency_id = '" . (int)$data['currency_id'] . "', currency_code = '" . $this->db->escape($data['currency_code']) . "', currency_value = '" . (float)$data['currency_value'] . "', ip = '" . $this->db->escape($data['ip']) . "', forwarded_ip = '" .  $this->db->escape($data['forwarded_ip']) . "', user_agent = '" . $this->db->escape($data['user_agent']) . "', accept_language = '" . $this->db->escape($data['accept_language']) . "', date_added = NOW(), date_modified = NOW() , order_status_id='".$this->getOrderStatusIdByName($data['order_status'])."'");

      $order_id = $this->db->getLastId();

        // Products
        foreach ($data['products'] as $product) {
            $this->db->query("INSERT INTO " . DB_PREFIX . "order_product SET order_id = '" . (int)$order_id . "', product_id = '" . (int)$product['product_id'] . "', name = '" . $this->db->escape($product['name']) . "', model = '" . $this->db->escape($product['model']) . "', quantity = '" . (int)$product['quantity'] . "', price = '" . (float)$product['price'] . "', total = '" . (float)$product['total'] . "', tax = '" . (float)$product['tax'] . "', reward = '" . (int)$product['reward'] . "'");

            $order_product_id = $this->db->getLastId();

            if(isset($product['option']) && count($product['option'])>0){
                foreach ($product['option'] as $option_id => $option_value) {
                $sql="SELECT pov.product_option_value_id,po.product_option_id,od.name, ovd.name as `value`,o.type FROM ".DB_PREFIX."product_option_value pov LEFT JOIN ".DB_PREFIX."product_option po ON (po.product_id=pov.product_id AND po.option_id=pov.option_id) LEFT JOIN ".DB_PREFIX."option o ON (pov.option_id =o.option_id) LEFT JOIN ".DB_PREFIX."option_description od ON (pov.option_id =od.option_id AND od.language_id = '" . (int)$data['language_id'] . "') JOIN ".DB_PREFIX."option_value_description ovd ON (pov.option_id =ovd.option_id AND pov.option_value_id=ovd.option_value_id AND ovd.language_id = '" . (int)$data['language_id'] . "') WHERE pov.option_value_id =". (int)$option_value." and pov.product_id=".(int)$product['product_id'];

                    $options_data=$this->db->query($sql);
                    if($options_data->num_rows){
                        $option=$options_data->row;
                        $this->db->query("INSERT INTO " . DB_PREFIX . "order_option SET order_id = '" . (int)$order_id . "', order_product_id = '" . (int)$order_product_id . "', product_option_id = '" . (int)$option['product_option_id'] . "', product_option_value_id = '" . (int)$option['product_option_value_id'] . "', name = '" . $this->db->escape($option['name']) . "', `value` = '" . $this->db->escape($option['value']) . "', `type` = '" . $this->db->escape($option['type']) . "'");
                    }
                }
            }
        }

        // Totals
        foreach ($data['totals'] as $total) {
            $this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = '" . (int)$order_id . "', code = '" . $this->db->escape($total['code']) . "', title = '" . $this->db->escape($total['title']) . "', `value` = '" . (float)$total['value'] . "', sort_order = '" . (int)$total['sort_order'] . "'");
        }

        $this->addOrderHistory($order_id, $this->getOrderStatusIdByName($data['order_status']));

        return $order_id;
    }

    public function addOrderHistory($order_id, $order_status_id, $comment ='',$notify = true)
    {
        $this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$order_id . "', order_status_id = '" . (int)$order_status_id . "', notify = '" . (int)$notify . "', comment = '" . $this->db->escape($comment) . "', date_added = NOW()");
        $data=array();
        $data['order_status_id']=(int)$order_status_id;
        $data['order_id']=(int)$order_id;
        $data['comment']='A Onbuy Order Imported Successfully';
        $data['notify']=(int)$notify;

        $order_info = $this->getOrder($order_id);

        if ($order_info) {
            // Restock
            $product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");

            foreach($product_query->rows as $product) {
                $this->db->query("UPDATE `" . DB_PREFIX . "product` SET quantity = (quantity - " . (int)$product['quantity'] . ") WHERE product_id = '" . (int)$product['product_id'] . "' AND subtract = '1'");

                $option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$product['order_product_id'] . "'");

                foreach ($option_query->rows as $option) {
                    $this->db->query("UPDATE " . DB_PREFIX . "product_option_value SET quantity = (quantity - " . (int)$product['quantity'] . ") WHERE product_option_value_id = '" . (int)$option['product_option_value_id'] . "' AND subtract = '1'");
                }
            }

            // If order status is 0 then becomes greater than 0 send main html email
            if ($order_status_id) {
                // Load the language for any mails that might be required to be sent out
                $language = new Language($order_info['language_code']);
                $language->load($order_info['language_code']);
                $language->load('mail/order');

                $order_status_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE order_status_id = '" . (int)$order_status_id . "' AND language_id = '" . (int)$order_info['language_id'] . "'");

                if ($order_status_query->num_rows) {
                    $order_status = $order_status_query->row['name'];
                } else {
                    $order_status = '';
                }

                $subject = sprintf($language->get('text_new_subject'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'), $order_id);

                // HTML Mail
                $data = array();

                $data['title'] = sprintf($language->get('text_new_subject'), $order_info['store_name'], $order_id);

                $data['text_greeting'] = sprintf($language->get('text_new_greeting'), $order_info['store_name']);
                $data['text_link'] = $language->get('text_new_link');
                $data['text_download'] = $language->get('text_new_download');
                $data['text_order_detail'] = $language->get('text_new_order_detail');
                $data['text_instruction'] = $language->get('text_new_instruction');
                $data['text_order_id'] = $language->get('text_new_order_id');
                $data['text_date_added'] = $language->get('text_new_date_added');
                $data['text_payment_method'] = $language->get('text_new_payment_method');
                $data['text_shipping_method'] = $language->get('text_new_shipping_method');
                $data['text_email'] = $language->get('text_new_email');
                $data['text_telephone'] = $language->get('text_new_telephone');
                $data['text_ip'] = $language->get('text_new_ip');
                $data['text_order_status'] = $language->get('text_new_order_status');
                $data['text_payment_address'] = $language->get('text_new_payment_address');
                $data['text_shipping_address'] = $language->get('text_new_shipping_address');
                $data['text_product'] = $language->get('text_new_product');
                $data['text_model'] = $language->get('text_new_model');
                $data['text_quantity'] = $language->get('text_new_quantity');
                $data['text_price'] = $language->get('text_new_price');
                $data['text_total'] = $language->get('text_new_total');
                $data['text_footer'] = $language->get('text_new_footer');

                $data['logo'] = $this->config->get('config_url') . 'image/' . $this->config->get('config_logo');
                $data['store_name'] = $order_info['store_name'];
                $data['store_url'] = $order_info['store_url'];
                $data['customer_id'] = $order_info['customer_id'];
                $data['link'] = $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id;

                $data['order_id'] = $order_id;
                $data['date_added'] = date($language->get('date_format_short'), strtotime($order_info['date_added']));
                $data['payment_method'] = $order_info['payment_method'];
                $data['shipping_method'] = $order_info['shipping_method'];
                $data['email'] = $order_info['email'];
                $data['telephone'] = $order_info['telephone'];
                $data['ip'] = $order_info['ip'];
                $data['order_status'] = $order_status;

                if ($comment && $notify) {
                    $data['comment'] = nl2br($comment);
                } else {
                    $data['comment'] = '';
                }

                if ($order_info['payment_address_format']) {
                    $format = $order_info['payment_address_format'];
                } else {
                    $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
                }

                $find = array(
                    '{firstname}',
                    '{lastname}',
                    '{company}',
                    '{address_1}',
                    '{address_2}',
                    '{city}',
                    '{postcode}',
                    '{zone}',
                    '{zone_code}',
                    '{country}'
                );

                $replace = array(
                    'firstname' => $order_info['payment_firstname'],
                    'lastname'  => $order_info['payment_lastname'],
                    'company'   => $order_info['payment_company'],
                    'address_1' => $order_info['payment_address_1'],
                    'address_2' => $order_info['payment_address_2'],
                    'city'      => $order_info['payment_city'],
                    'postcode'  => $order_info['payment_postcode'],
                    'zone'      => $order_info['payment_zone'],
                    'zone_code' => $order_info['payment_zone_code'],
                    'country'   => $order_info['payment_country']
                );

                $data['payment_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

                if ($order_info['shipping_address_format']) {
                    $format = $order_info['shipping_address_format'];
                } else {
                    $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
                }

                $find = array(
                    '{firstname}',
                    '{lastname}',
                    '{company}',
                    '{address_1}',
                    '{address_2}',
                    '{city}',
                    '{postcode}',
                    '{zone}',
                    '{zone_code}',
                    '{country}'
                );

                $replace = array(
                    'firstname' => $order_info['shipping_firstname'],
                    'lastname'  => $order_info['shipping_lastname'],
                    'company'   => $order_info['shipping_company'],
                    'address_1' => $order_info['shipping_address_1'],
                    'address_2' => $order_info['shipping_address_2'],
                    'city'      => $order_info['shipping_city'],
                    'postcode'  => $order_info['shipping_postcode'],
                    'zone'      => $order_info['shipping_zone'],
                    'zone_code' => $order_info['shipping_zone_code'],
                    'country'   => $order_info['shipping_country']
                );

                $data['shipping_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));


                // Products
                $data['products'] = array();
                $data['vouchers'] = array();

                foreach ($product_query->rows as $product) {
                    $option_data = array();

                    $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$product['order_product_id'] . "'");

                    foreach ($order_option_query->rows as $option) {
                        $value = $option['value'];

                        $option_data[] = array(
                            'name'  => $option['name'],
                            'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
                        );
                    }

                    $data['products'][] = array(
                        'name'     => $product['name'],
                        'model'    => $product['model'],
                        'option'   => $option_data,
                        'quantity' => $product['quantity'],
                        'price'    => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
                        'total'    => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value'])
                    );
                }



                // Order Totals
                $data['totals'] = array();

                $order_total_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order_total` WHERE order_id = '" . (int)$order_id . "' ORDER BY sort_order ASC");

                foreach ($order_total_query->rows as $total) {
                    $data['totals'][] = array(
                        'title' => $total['title'],
                        'text'  => $this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']),
                    );
                }

                // Text Mail
                $text  = sprintf($language->get('text_new_greeting'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8')) . "\n\n";
                $text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
                $text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
                $text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";

                if ($comment && $notify) {
                    $text .= $language->get('text_new_instruction') . "\n\n";
                    $text .= $comment . "\n\n";
                }

                // Products
                $text .= $language->get('text_new_products') . "\n";

                foreach ($product_query->rows as $product) {
                    $text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

                    $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

                    foreach ($order_option_query->rows as $option) {
                        $value = $option['value'];

                        $text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value) . "\n";
                    }
                }


                $text .= "\n";

                $text .= $language->get('text_new_order_total') . "\n";

                foreach ($order_total_query->rows as $total) {
                    $text .= $total['title'] . ': ' . html_entity_decode($this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";
                }

                $text .= "\n";

                if ($order_info['customer_id']) {
                    $text .= $language->get('text_new_link') . "\n";
                    $text .= $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id . "\n\n";
                }

                // Comment
                if ($order_info['comment']) {
                    $text .= $language->get('text_new_comment') . "\n\n";
                    $text .= $order_info['comment'] . "\n\n";
                }
                $text .= $language->get('text_new_footer') . "\n\n";

                $mail = new Mail();
                $mail->protocol = $this->config->get('config_mail_protocol');
                $mail->parameter = $this->config->get('config_mail_parameter');
                $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
                $mail->smtp_username = $this->config->get('config_mail_smtp_username');
                $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
                $mail->smtp_port = $this->config->get('config_mail_smtp_port');
                $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

                $mail->setTo($order_info['email']);
                $mail->setFrom($this->config->get('config_email'));
                $mail->setSender(html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'));
                $mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
                //$mail->setHtml($this->load->view('mail/order.tpl', $data));
                $mail->setText($text);
                $mail->send();

                // Admin Alert Mail
                if ($this->config->get('config_order_mail')) {
                    $subject = sprintf($language->get('text_new_subject'), html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'), $order_id);

                    // HTML Mail
                    $data['text_greeting'] = $language->get('text_new_received');

                    if ($comment) {
                        if ($order_info['comment']) {
                            $data['comment'] = nl2br($comment) . '<br/><br/>' . $order_info['comment'];
                        } else {
                            $data['comment'] = nl2br($comment);
                        }
                    } else {
                        if ($order_info['comment']) {
                            $data['comment'] = $order_info['comment'];
                        } else {
                            $data['comment'] = '';
                        }
                    }

                    $data['text_download'] = '';

                    $data['text_footer'] = '';

                    $data['text_link'] = '';
                    $data['link'] = '';
                    $data['download'] = '';

                    // Text
                    $text  = $language->get('text_new_received') . "\n\n";
                    $text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
                    $text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
                    $text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";
                    $text .= $language->get('text_new_products') . "\n";

                    foreach ($product_query->rows as $product) {
                        $text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

                        $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

                        foreach ($order_option_query->rows as $option) {
                            if ($option['type'] != 'file') {
                                $value = $option['value'];
                            } else {
                                $value = utf8_substr($option['value'], 0, utf8_strrpos($option['value'], '.'));
                            }

                            $text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value) . "\n";
                        }
                    }

                    foreach ($order_voucher_query->rows as $voucher) {
                        $text .= '1x ' . $voucher['description'] . ' ' . $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value']);
                    }

                    $text .= "\n";

                    $text .= $language->get('text_new_order_total') . "\n";

                    foreach ($order_total_query->rows as $total) {
                        $text .= $total['title'] . ': ' . html_entity_decode($this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";
                    }

                    $text .= "\n";

                    if ($order_info['comment']) {
                        $text .= $language->get('text_new_comment') . "\n\n";
                        $text .= $order_info['comment'] . "\n\n";
                    }

                    $mail = new Mail();
                    $mail->protocol = $this->config->get('config_mail_protocol');
                    $mail->parameter = $this->config->get('config_mail_parameter');
                    $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
                    $mail->smtp_username = $this->config->get('config_mail_smtp_username');
                    $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
                    $mail->smtp_port = $this->config->get('config_mail_smtp_port');
                    $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

                    $mail->setTo($this->config->get('config_email'));
                    $mail->setFrom($this->config->get('config_email'));
                    $mail->setSender(html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'));
                    $mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
                    //$mail->setHtml($this->load->view('mail/order.tpl', $data));
                    $mail->setText($text);
                    $mail->send();

                    // Send to additional alert emails
                    $emails = explode(',', $this->config->get('config_mail_alert'));
                    foreach ($emails as $email) {
                        if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            $mail->setTo($email);
                            $mail->send();
                        }
                    }
                }
            }
        }
    }
    
    public function getOrder($order_id)
    {
        $order_query = $this->db->query("SELECT *, (SELECT CONCAT(c.firstname, ' ', c.lastname) FROM " . DB_PREFIX . "customer c WHERE c.customer_id = o.customer_id) AS customer FROM `" . DB_PREFIX . "order` o WHERE o.order_id = '" . (int)$order_id . "'");

        if ($order_query->num_rows) {
            $reward = 0;

            $order_product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");

            foreach ($order_product_query->rows as $product) {
                $reward += $product['reward'];
            }

            $country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['payment_country_id'] . "'");

            if ($country_query->num_rows) {
                $payment_iso_code_2 = $country_query->row['iso_code_2'];
                $payment_iso_code_3 = $country_query->row['iso_code_3'];
            } else {
                $payment_iso_code_2 = '';
                $payment_iso_code_3 = '';
            }

            $zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['payment_zone_id'] . "'");

            if ($zone_query->num_rows) {
                $payment_zone_code = $zone_query->row['code'];
            } else {
                $payment_zone_code = '';
            }

            $country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['shipping_country_id'] . "'");

            if ($country_query->num_rows) {
                $shipping_iso_code_2 = $country_query->row['iso_code_2'];
                $shipping_iso_code_3 = $country_query->row['iso_code_3'];
            } else {
                $shipping_iso_code_2 = '';
                $shipping_iso_code_3 = '';
            }

            $zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['shipping_zone_id'] . "'");

            if ($zone_query->num_rows) {
                $shipping_zone_code = $zone_query->row['code'];
            } else {
                $shipping_zone_code = '';
            }

            if ($order_query->row['affiliate_id']) {
                $affiliate_id = $order_query->row['affiliate_id'];
            } else {
                $affiliate_id = 0;
            }

            $affiliate_firstname = '';
            $affiliate_lastname = '';

            $language_code = '';
            $language_filename = '';
            $language_directory = '';

            return array(
                'order_id'                => $order_query->row['order_id'],
                'invoice_no'              => $order_query->row['invoice_no'],
                'invoice_prefix'          => $order_query->row['invoice_prefix'],
                'store_id'                => $order_query->row['store_id'],
                'store_name'              => $order_query->row['store_name'],
                'store_url'               => $order_query->row['store_url'],
                'customer_id'             => $order_query->row['customer_id'],
                'customer'                => $order_query->row['customer'],
                'customer_group_id'       => $order_query->row['customer_group_id'],
                'firstname'               => $order_query->row['firstname'],
                'lastname'                => $order_query->row['lastname'],
                'email'                   => $order_query->row['email'],
                'telephone'               => $order_query->row['telephone'],
                'fax'                     => $order_query->row['fax'],
                'custom_field'            => unserialize($order_query->row['custom_field']),
                'payment_firstname'       => $order_query->row['payment_firstname'],
                'payment_lastname'        => $order_query->row['payment_lastname'],
                'payment_company'         => $order_query->row['payment_company'],
                'payment_address_1'       => $order_query->row['payment_address_1'],
                'payment_address_2'       => $order_query->row['payment_address_2'],
                'payment_postcode'        => $order_query->row['payment_postcode'],
                'payment_city'            => $order_query->row['payment_city'],
                'payment_zone_id'         => $order_query->row['payment_zone_id'],
                'payment_zone'            => $order_query->row['payment_zone'],
                'payment_zone_code'       => $payment_zone_code,
                'payment_country_id'      => $order_query->row['payment_country_id'],
                'payment_country'         => $order_query->row['payment_country'],
                'payment_iso_code_2'      => $payment_iso_code_2,
                'payment_iso_code_3'      => $payment_iso_code_3,
                'payment_address_format'  => $order_query->row['payment_address_format'],
                'payment_custom_field'    => unserialize($order_query->row['payment_custom_field']),
                'payment_method'          => $order_query->row['payment_method'],
                'payment_code'            => $order_query->row['payment_code'],
                'shipping_firstname'      => $order_query->row['shipping_firstname'],
                'shipping_lastname'       => $order_query->row['shipping_lastname'],
                'shipping_company'        => $order_query->row['shipping_company'],
                'shipping_address_1'      => $order_query->row['shipping_address_1'],
                'shipping_address_2'      => $order_query->row['shipping_address_2'],
                'shipping_postcode'       => $order_query->row['shipping_postcode'],
                'shipping_city'           => $order_query->row['shipping_city'],
                'shipping_zone_id'        => $order_query->row['shipping_zone_id'],
                'shipping_zone'           => $order_query->row['shipping_zone'],
                'shipping_zone_code'      => $shipping_zone_code,
                'shipping_country_id'     => $order_query->row['shipping_country_id'],
                'shipping_country'        => $order_query->row['shipping_country'],
                'shipping_iso_code_2'     => $shipping_iso_code_2,
                'shipping_iso_code_3'     => $shipping_iso_code_3,
                'shipping_address_format' => $order_query->row['shipping_address_format'],
                'shipping_custom_field'   => unserialize($order_query->row['shipping_custom_field']),
                'shipping_method'         => $order_query->row['shipping_method'],
                'shipping_code'           => $order_query->row['shipping_code'],
                'comment'                 => $order_query->row['comment'],
                'total'                   => $order_query->row['total'],
                'reward'                  => $reward,
                'order_status_id'         => $order_query->row['order_status_id'],
                'affiliate_id'            => $order_query->row['affiliate_id'],
                'affiliate_firstname'     => $affiliate_firstname,
                'affiliate_lastname'      => $affiliate_lastname,
                'commission'              => $order_query->row['commission'],
                'language_id'             => $order_query->row['language_id'],
                'language_code'           => $language_code,
                'language_filename'       => $language_filename,
                'language_directory'      => $language_directory,
                'currency_id'             => $order_query->row['currency_id'],
                'currency_code'           => $order_query->row['currency_code'],
                'currency_value'          => $order_query->row['currency_value'],
                'ip'                      => $order_query->row['ip'],
                'forwarded_ip'            => $order_query->row['forwarded_ip'],
                'user_agent'              => $order_query->row['user_agent'],
                'accept_language'         => $order_query->row['accept_language'],
                'date_added'              => $order_query->row['date_added'],
                'date_modified'           => $order_query->row['date_modified']
            );
        } else {
            return;
        }
    }

    public function getTrackingDetailsById($tracking_id = '')
    {
      $sql = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedonbuy_tracking` WHERE `tracking_id` = '". (int)$tracking_id ."' ");
      if($sql->num_rows)
      {
        return array(
          'tracking_id' => $tracking_id,
          'number' => $sql->row['name'],
          'url' => $sql->row['url'],
          );
      } else {
        return array();
      }
    }

    public function cancelOrder($cancel_order_data = array())
    {
      $response = array();
      $path = 'orders/cancel?site_id='.$this->config->get('ced_onbuy_site_id');
      $cancel_order_data_array = array(
          'order_id' => $cancel_order_data['onbuy_order_id'],
          'order_cancellation_reason_id' => $cancel_order_data['cancelationReason'],
        );

      if($cancel_order_data['cancelationReason'] == '5')
        $cancel_order_data_array['cancel_order_additional_info'] = $cancel_order_data['reasonNote'];

      $params = array(
        'orders' => array($cancel_order_data_array)
        );

      // $params = json_encode($params);

      $access_token = $this->config->get('ced_onbuy_access_token');
      $access_token_expiry = $this->config->get('ced_onbuy_expires_at');
      $now = strtotime(date('Y-m-d h:i:s a'));
      
      if(!empty($access_token) && !empty($access_token_expiry) && ($access_token_expiry > $now))
      {
        $this->updateAccessToken();
      }

      $response = $this->putRequest($path, $params, 'PUT');
        
      if(isset($response['status']) && $response['status'] == true)
      {
        $response = $response['response'];
        $response = $response['result'];
        if(isset($response['0']['success']) && $response['0']['success'] == true)
        {
          $this->db->query("UPDATE `". DB_PREFIX ."cedonbuy_order` SET onbuy_status = 'CANCELLED' WHERE onbuy_order_id = '". $onbuy_order_id ."' ");
          $this->updateOrderStatus($onbuy_order_id, 'Cancelled');
          $response = array('success' => true, 'message' => 'Order Cancelled Successfully');
        } else {
          if(isset($response['0']['message']) && !empty($response['0']['message']))
            $response = array('success' => false, 'message' => $response['0']['message']);
          else
            $response = array('success' => false, 'message' => 'Something went wrong while cancelling order'. $onbuy_order_id);
        }
      } else {
        $response = array('success' => false, 'message' => $request['response']);
      }
        return $response;
    }

    public function dispatchOrder($dispatch_order_data = array())
    {
      $response = array();
      $path = 'orders/dispatch';
      
      if(!empty($dispatch_order_data['trackingId']))
        $tracking_array = $this->getTrackingDetailsById($dispatch_order_data['trackingId']);

      $dispatch_order_data_array['order_id'] = $dispatch_order_data['onbuy_order_id'];
      if(isset($tracking_array) && is_array($tracking_array) && !empty($tracking_array))
        $dispatch_order_data_array['tracking'] = $tracking_array;
        
      $params = array(
        'site_id' => $this->config->get('ced_onbuy_site_id'),
          'orders' => array($dispatch_order_data_array)
      );
      //$params = json_encode($params);

      $access_token = $this->config->get('ced_onbuy_access_token');
      $access_token_expiry = $this->config->get('ced_onbuy_expires_at');
      $now = strtotime(date('Y-m-d h:i:s a'));
      
      if(!empty($access_token) && !empty($access_token_expiry) && ($access_token_expiry > $now))
      {
        $this->updateAccessToken();
      }
    
      $response = $this->putRequest($path, $params, 'PUT');
        
      if(isset($response['status']) && $response['status'] == true)
      {
        $response = $response['response'];
        $response = $response['results'];
        if(isset($response[$onbuy_order_id]) && $response[$onbuy_order_id] && isset($response[$onbuy_order_id]['success']) && ($response[$onbuy_order_id]['success'] == true))
        {
          $this->db->query("UPDATE `". DB_PREFIX ."cedonbuy_order` SET onbuy_status = 'SHIPPED' WHERE onbuy_order_id = '". $onbuy_order_id ."' ");
          $this->updateOrderStatus($onbuy_order_id, 'Shipped');
          $response = array('success' => true, 'message' => 'Order '. $onbuy_order_id .' Shipped Successfully');
        } else if(isset($response[$onbuy_order_id]['errorcode']) && $response[$onbuy_order_id]['errorcode'])
        {
          if(!empty($response[$onbuy_order_id]['message']))
            $response = array('success' => false, 'message' => $response[$onbuy_order_id]['message']);
          else
            $response = array('success' => false, 'message' => 'Something went wrong while shipping order'.$onbuy_order_id);
        }
      } else {
        $response = array('success' => false, 'message' => $request['response']);
      }
    return $response;
    }

    public function getOnbuyProductDataByOPC($onbuy_order_id, $opcs = array())
    {
      $response = array();
      $sql = $this->db->query("SELECT * FROM `". DB_PREFIX ."cedonbuy_order` WHERE `onbuy_order_id` = '". $this->db->escape($onbuy_order_id) ."' ");
      if($sql->num_rows)
      {
        $result = $sql->row;
        $orderData = json_decode($result['order_data'], true);
        $response['delivery'] = $orderData['price_delivery'];
        
        foreach($orderData['products'] as $key => $value)
        {
          if(in_array($value['opc'], $opcs))
          {
            $response['items'][] = array(
              'onbuy_internal_reference' => $value['onbuy_internal_reference'],
              'amount' => $value['total_price']
              );
          }
        }
      }
      return $response;
    }

    public function refundOrder($refund_order_data = array())
    {
      //echo '<pre>'; print_r($refund_order_data); die;
      $response = array();

      if(isset($refund_order_data['refundItems']) && is_array($refund_order_data['refundItems']))
      {
        $product_data = $this->getOnbuyProductDataByOPC($refund_order_data['onbuy_order_id'], $refund_order_data['refundItems']);
      }
      
      $path = 'orders/refund?site_id='.$this->config->get('ced_onbuy_site_id');
      $refund_order_data_array = array(
          'order_id' => $refund_order_data['onbuy_order_id'],
          'order_refund_reason_id' => $refund_order_data['refundReasonId'],
          'delivery' => isset($product_data['delivery']) ? $product_data['delivery'] : '0',
          'items' => isset($product_data['items']) ? $product_data['items'] : array(),
          'seller_note' => $refund_order_data['refundSellerNotes'],
          'customer_note' => $refund_order_data['refundCustomerNotes']
        );
      
      $params = array(
        'orders' => array($refund_order_data_array)
        );

      //$params = json_encode($params);

      $access_token = $this->config->get('ced_onbuy_access_token');
      $access_token_expiry = $this->config->get('ced_onbuy_expires_at');
      $now = strtotime(date('Y-m-d h:i:s a'));
      
      if(!empty($access_token) && !empty($access_token_expiry) && ($access_token_expiry > $now))
      {
        $this->updateAccessToken();
      }
    
      $response = $this->putRequest($path, $params, 'PUT');
        
      if(isset($response['status']) && $response['status'] == true)
      {
        $response = $response['response'];
        $response = $response['results'];
        if(isset($response['0']) && $response['0'] && isset($response['0']['success']) && ($response['0']['success'] == true))
        {
          $this->db->query("UPDATE `". DB_PREFIX ."cedonbuy_order` SET onbuy_status = 'REFUNDED' WHERE onbuy_order_id = '". $onbuy_order_id ."' ");
          $this->updateOrderStatus($onbuy_order_id, 'Refunded');
          $response = array('success' => true, 'message' => 'Order '. $onbuy_order_id .' Refunded Successfully');
        } else if(isset($response['0']['errorcode']) && $response['0']['errorcode'])
        {
          if(!empty($response['0']['message']))
            $response = array('success' => false, 'message' => $response['0']['message']);
          else
            $response = array('success' => false, 'message' => 'Something went wrong while refunding order'.$onbuy_order_id);
        }
      } else {
        $response = array('success' => false, 'message' => $request['response']);
      }
    return $response;
    }

    public function getValidationArray(){

    return array(
          'site_id' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 50,
                'description' => "Onbuy Site Id"
            ),
            'uid' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 50,
                'description' => "For product batches only: a seller's own unique reference for a product used to link the sent product details with the JSON response "
            ),
            'category_id' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 10,
                'description' => "Onbuy Category Id. "
            ),
            'published' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 1,
                'description' => "If the product should be published to the site once it's created. Products not published will need to be completed through the SCP. This can be used to review the product before it is displayed publically. Use 1 for published and 0 for not published."
            ),
            'product_name' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 150,
                'description' => 'Name of the product.'
            ),
            'mpn' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 100,
                'description' => 'MPN of product.'
            ),
            'product_codes' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 5000,
                'description' => 'Unique Code of Products.'
            ),
            'summary_points' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 500,
                'description' => 'Maximum length 500 characters. A maximum of 5 summary points are supported. '
            ),
            'description' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 50000,
                'description' => 'Description of Product. Maximum length 50k characters..'
            ),
            'brand_name' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 200,
                'description' => 'You may supply either a brand name or a brand ID. Maximum length 200 characters.'
            ),
            'brand_id' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'Use Onbuy Brand Id. Use 1 for Unbranded products.'
            ),
            'videos' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 500,
                'description' => 'Maximum label length 500 characters.'
            ),
            'documents' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 500,
                'description' => 'Maximum label length 500 characters.'
            ),
            'rrp' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 7,
                'description' => "The price of the variation when the user purchases one, max 100,000."
            )
        );
    }

    // function validDate($date, $format = 'Y-m-d')
    // {
    //     $date_obj = DateTime::createFromFormat($format, $date);
    //     return $date_obj && $date_obj->format($format) == $date;
    // }

    public function updateStock($product_ids=array(), $keyFor)
    {
        if(is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0) {
            $product_ids = $this->getAllMappedProducts();

            if(empty($product_ids))
                $product_ids = $this->getAllOnbuyProducts();

            $product_ids = array_unique($product_ids);
        }
        try{

            if(count($product_ids))
            {
                $productids_chunk = array_chunk($product_ids,'999');
                $inventory_chunk = array();

                $sql = $this->db->query("SELECT `inventory_chunk` FROM `" . DB_PREFIX . "cedonbuy_products_cron` WHERE `type` = 'updatestock'");
                $result = $sql->rows;
                if (count($result) && isset($result[0]['inventory_chunk']) && count($result[0]['inventory_chunk'])) {
                    $inventory_chunk = json_decode($result[0]['inventory_chunk'], true);
                }
                $finalInventoryChunk = array();
                if (!count($inventory_chunk)) {
                    $this->db->query("INSERT INTO `". DB_PREFIX ."cedonbuy_products_cron` (`inventory_chunk`, `type`) VALUES ('". $this->db->escape(json_encode($productids_chunk)) ."', 'updatestock') ");

                    $inventory_chunk = $productids_chunk;
                } else {
                    foreach ($inventory_chunk as $chunk) {
                        if (is_array($chunk)) {
                            foreach ($chunk as $id) {
                                $finalInventoryChunk[] = $id;
                            }
                        }
                    }
                    foreach ($productids_chunk as $chunk) {
                        if (is_array($chunk)) {
                            foreach ($chunk as $id) {
                                $finalInventoryChunk[] = $id;
                            }
                        }
                    }
                    $inventory_chunk = array_unique($finalInventoryChunk);
                    $inventory_chunk = array_chunk($inventory_chunk, 999);
                }

                $response = array();
                foreach ($inventory_chunk as $chk => $product_ids) 
                {
                    $updatestock = array();
                    $prod_ids = array_chunk($product_ids,'100');

                    $feed_array = array();
                    foreach ($prod_ids as $key => $prod_id)
                    {
                        foreach ($prod_id as $product_id)
                        {

                            $query = $this->db->query("SELECT profile_id FROM `".DB_PREFIX."cedonbuy_profile_products` WHERE product_id = '". $product_id ."' ");
                            
                            $result = $query->row;

                            $product = $this->getProduct($product_id);

                            $product_combination = $this->isVariantProduct($product_id, $product);

                            if(!empty($product_combination))
                            {
                                foreach($product_combination as $single_combi)
                                {
                                  $updatestock[] = array(
                                      'sku' => $single_combi['sku'],
                                      'stock' => $single_combi['stock'],
                                      'price' => $single_combi['price']
                                  );
                                }
                            } else {

                                $query = $this->db->query("SELECT quantity, price FROM " . DB_PREFIX . "product WHERE `product_id` ='".$product_id."'");

                                $sku_query = $this->db->query("SELECT sku FROM `". DB_PREFIX ."cedonbuy_profile_products` WHERE product_id = '". $product_id ."' ");

                                $updatestock[] = array(
                                      'sku' => $sku_query->row['sku'],
                                      'stock' => $query->row['quantity'],
                                      'price' => $query->row['price']
                                  );
                            }
                        }
                    }

                    if($updatestock){

                        $params = json_encode($updatestock);
                        $path = 'listings/by-sku';
                        $final_array = array(
                            'listings' => $params,
                            'site_id' => $this->config->get('ced_onbuy_site_id')
                        );

                        $listingResponse = $this->postRequest($path, $final_array);
                        $error_message = '';
                        if(isset($listingResponse['status']) && $listingResponse['status'] == true)
                        {
                          $response = $listingResponse['response'];
                          if(isset($response['results']) && is_array($response['results']))
                          {
                            
                            foreach($response['results'] as $key => $value)
                            {
                              if(isset($value['error']) && !empty($value['error']))
                              {
                                $error_message .= 'For Product SKU : ' . $value['sku'] . $value['error'] . '<br/>';

                                $this->db->query("DELETE FROM `". DB_PREFIX ."cedonbuy_products_cron` WHERE `type` = 'updatestock' ");

                                unset($inventory_chunk[$chk]);
                                $inventory_chunk = array_values($inventory_chunk);

                                $this->db->query("INSERT INTO `". DB_PREFIX ."cedonbuy_products_cron` (`inventory_chunk`, `type`) VALUES ('". $this->db->escape(json_encode($inventory_chunk)) ."', 'updatestock') ");

                              }
                            }
                            $response = array('success' => true, 'message' => 'Product Synced Successfully!', 'error' => $error_message);
                          }
                        } else {
                          $response = array('success'=> false, 'message' => $request['response'], 'error' => $error_message);
                        }
                    }
                }
                return $response;
            }
        } catch(Exception $e){
            $this->log($e->getMessage());
        }
    }

    public function getOptionAttribute($product_id, $sku, $combi_array = array())
    {
        $option_attributes = array();
        $query = $this->db->query("SELECT combination FROM `". DB_PREFIX ."cedonbuy_product_attribute_combination` WHERE product_id = '". $product_id ."' AND SkuId = '". $sku ."' ");
        $result = $query->rows;
        $combination = array();
        if(isset($result) && !empty($result))
        {
            foreach($result as $key)
            {
                $combination = json_decode($key['combination'], true);
                $quantity_array = array();
                //$quantity = '0';
                foreach($combination as $option_id => $name)
                {
                    if($option_id != 'sku')
                    {
                        $option_value_query = $this->db->query("SELECT pov.quantity FROM `". DB_PREFIX ."option_value_description` AS ovd JOIN `". DB_PREFIX ."product_option_value` AS pov ON (ovd.option_value_id = pov.option_value_id) WHERE ovd.option_id = '". $option_id ."' AND ovd.name = '". $name ."' AND pov.product_id = '". $product_id ."' ");
                        $option_value_res = $option_value_query->row;

                        if(isset($option_value_res['quantity']) && $option_value_res['quantity'])
                            $quantity_array[] = $option_value_res['quantity'];
//                        if(!empty($option_value_res['quantity']))
//                            $quantity = $option_value_res['quantity'];
//                        else
//                            $quantity = '0';
                    }
                }
                $option_attributes = array('quantity' => min($quantity_array));
                //echo '<pre>'; print_r($option_attributes); die;
                return $option_attributes;
            }
        } else {
            if(!isset($combi_array['0'])){
                $temp_combi_array = $combi_array;
                $combi_array = array();
                $combi_array['0'] = $temp_combi_array;
            }
            foreach($combi_array as $key)
            {
                //$quantity = '0';
                $quantity_array = array();
                foreach($key as $option_id => $name)
                {
                    if($option_id != 'sku'){
                        $option_value_query = $this->db->query("SELECT pov.quantity FROM `". DB_PREFIX ."option_value_description` AS ovd JOIN `". DB_PREFIX ."product_option_value` AS pov ON (ovd.option_value_id = pov.option_value_id) WHERE ovd.option_id = '". $option_id ."' AND ovd.name = '". $name ."' AND pov.product_id = '". $product_id ."' ");
                        $option_value_res = $option_value_query->row;
                        if(isset($option_value_res['quantity']) && $option_value_res['quantity'])
                            $quantity_array[] = $option_value_res['quantity'];
//                        if(!empty($option_value_res['quantity']))
//                            $quantity+=$option_value_res['quantity'];
//                        else
//                            $quantity = '0';
                    }
                }
                $option_attributes = array('quantity' => min($quantity_array));
                return $option_attributes;
            }
        }
    }

    public function syncStatus($product_ids=array())
    {
        $response = array();
        try
        {
            if(is_numeric($product_ids)) {
                $product_ids = array($product_ids);
            }
            if(count($product_ids)==0)
            {
                $product_ids = $this->getAllMappedProducts();

                if(empty($product_ids))
                    $product_ids = $this->getAllOnbuyProducts();

                $product_ids = array_unique($product_ids);
            }

            if(count($product_ids))
            {
                $queue_ids = array();
                $product_not_uploaded = array();
                foreach($product_ids as $key => $product_id)
                {
                    $query = $this->db->query("SELECT onbuy_queue_id FROM `". DB_PREFIX ."cedonbuy_profile_products` WHERE product_id = '". $product_id ."' AND profile_id > '0' ");

                    if(isset($query->row['onbuy_queue_id']) && !empty($query->row['onbuy_queue_id']))
                        $queue_ids[] = $query->row['onbuy_queue_id'] . ',';
                    else
                        $product_not_uploaded[] = $product_id;
                }

                    $path = 'queues';
                    $params['site_id'] =  $this->config->get('ced_onbuy_site_id');

                    if(isset($queue_ids) && !empty($queue_ids))
                    {
                        $params['filter']['queue_ids'] = implode(',', $queue_ids);
                    }

                    $statusResponse = $this->getRequest($path, $params);
                    //echo '<pre>'; print_r($statusResponse); die;
                    $error_message = '';
                    if(isset($statusResponse['status']) && $statusResponse['status'] == true)
                    {
                        $response = $statusResponse['response'];

                        if(isset($response['results']) && !empty($response['results']))
                        {
                            foreach($response['results'] as $key => $value)
                            {
                                if(isset($value['opc']))
                                    $opc = $value['opc'];
                                elseif(isset($value['existing_opc']))
                                    $opc = $value['existing_opc'];
                                else
                                    $opc = '';

                                if($value['status'] == 'failed')
                                    $this->db->query("UPDATE `". DB_PREFIX ."cedonbuy_profile_products` SET onbuy_status = '". $value['status'] ."', opc = '' WHERE onbuy_queue_id = '". $value['queue_id'] ."' ");
                                else
                                    $this->db->query("UPDATE `". DB_PREFIX ."cedonbuy_profile_products` SET onbuy_status = '". $value['status'] ."', opc = '". $opc ."' WHERE onbuy_queue_id = '". $value['queue_id'] ."' ");

                                if(isset($value['error_message']))
                                {
                                    $sql = $this->db->query("SELECT `product_id` FROM `". DB_PREFIX ."cedonbuy_profile_products` WHERE onbuy_queue_id = '". $value['queue_id'] ."' ");
                                    $product_id = $sql->row['product_id'];
                                    $error_message .= 'Product ID : ' . $product_id . ' - ' . $value['error_message'] . '<br/>';
                                }
                            }
                            $response = array('success' => true, 'message'=> 'Product(s) Status Synced Successfully!' . $error_message);
                        } else {
                            $response = array('success' => false, 'message'=> 'Product ID(s) - ' . implode(', ', $product_not_uploaded) . 'No response from Onbuy');
                        }
                    } else {
                        $response = array('success' => false, 'message'=> $statusResponse['response'] . ' - ' .$error_message);
                    }
//                } else {
//                    $response = array('success' => false, 'message' => 'Can\'t sync status. Product ID(s) - ' . implode(', ', $product_not_uploaded) . ' not uploaded at Onbuy.');
//                }
            } else {
                $response = array('success' => false, 'message' => 'No category mapped yet!');
            }
        } catch (Exception $e) {
            $response = array('success' => false, 'message' => $e->getMessage());
        }
        return $response;
    }

}

?>
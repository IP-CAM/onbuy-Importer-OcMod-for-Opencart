<?php
class ControllerCedOnbuyProduct extends Controller {
    private $error = array();


    public function syncProductData()
    {
        $json = array();
        $this->load->library('cedonbuy');
        $cedonbuy = Cedonbuy::getInstance($this->registry);
        $product_ids = array();
        $productIds = $cedonbuy->getAllMappedProducts();
        if(empty($productIds))
            $productIds = $cedonbuy->getAllOnbuyProducts();
        
        if (isset($productIds) && is_array($productIds) && $productIds) {
            //$product_ids = (array)$productIds;
            
            $response = $cedonbuy->updateStock($productIds, 'syncProduct');

            if (isset($response['success']) && $response['success']) {
                if (!is_array($response['message']))
                    $json['message'] = $response['message'];
                else
                    $json['message'] = 'Product(s) Synced Successfully.';
                $json['success'] = true;
            } else {
                $json['success'] = false;
                $json['message'] = isset($response['message'])?$response['message']:'No product to sync.';
            }
        } else {
            $json['success'] = false;
            $json['message'] = 'No Category Mapped yet';
        }

        //$this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function syncStatus()
    {
        $this->load->library('cedonbuy');
        $cedonbuy = Cedonbuy::getInstance($this->registry);
        $product_ids = array();
        $productIds = $cedonbuy->getAllMappedProducts();
        if(empty($productIds))
            $productIds = $cedonbuy->getAllOnbuyProducts();

        $json = array();
        if (isset($productIds) && is_array($productIds) && $productIds) {
            //$product_ids = (array)$productIds;
            $response = $cedonbuy->syncStatus($productIds);

            if (isset($response['success']) && $response['success']) {

                if(is_array($response['message']) && !empty($response['message'])){
                    $message = $response['message']['0']['error'];
                    $json['message'] = $message;
                    $json['success'] = false;
                }
                else{
                    $json['message'] = 'Product(s) Status Fetched Successfully.';
                    $json['success'] = true;
                }

            } else {
                $json['success'] = false;
                $json['message'] = ($response['message'])?$response['message']:'No product to fetch.';
            }
        } else {
            $json['success'] = false;
            $json['message'] = 'No Category Mapped yet';
        }

        //$this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function uploadAllProducts()
    {
        $json = array();
        $this->load->library('cedonbuy');
        $cedonbuy = Cedonbuy::getInstance($this->registry);

        $productIds = $cedonbuy->getAllMappedProducts();
        if(empty($productIds))
            $productIds = $cedonbuy->getAllOnbuyProducts();

        try{
            if ($productIds && count($productIds))
            {
//                $total_product = count($productIds);
//                $array_chunk_count = ceil($total_product/10);
                $productIds = array_chunk($productIds,100);

                if(count($productIds) > 0){
                    foreach($productIds as $key => $product_ids)
                    {
                        $response = $cedonbuy->uploadProducts($product_ids);

                        if (isset($response['success']) && $response['success']) {
                            if (!is_array($response['message']))
                                $json['message'][] = 'Uploading Product Id(s) '.implode(',', $product_ids).' : '.$response['message'];
                            else
                                $json['message'][] = 'Uploading Product Id(s) '.implode(',', $product_ids).' : ' .implode(',',$response['message'] );
                            $json['success'] = true;
                        } else {
                            $json['success'] = false;
                            $json['message'][] = ($response['message'])?$response['message']:'No response to upload see log.';
                        }
                    }
                    echo '<pre>'; print_r(json_encode($json)); die;
                }
            } else {
                $json['success'] = false;
                $json['message'] = 'No Category Mapped yet';
                echo '<pre>'; print_r(json_encode($json)); die;
            }
        } catch(Exception $e){
            $json['success'] = false;
            $json['message'] = $e->getMessage();
            echo '<pre>'; print_r(json_encode($json)); die;
        }

        $this->response->setOutput(json_encode($json));
    }

}
?>
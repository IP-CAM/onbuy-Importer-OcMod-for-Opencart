<?php
class ControllerCedOnbuyOrder extends Controller {
	private $error = array();

	public function fetchOrder() 
	{
		$json = array();
		$this->load->library('cedonbuy');
		$this->load->language('ced_onbuy/order');
		//$this->load->model('ced_wish/order');
		$cedonbuy = Cedonbuy::getInstance($this->registry); 
        
		$response = $cedonbuy->fetchOrders();

		if(isset($response['success']) && $response['success']) 
		{
			$json['success'] = true;
			if(count($response['message']))
			$json['message'] = isset($response['message']) ? $response['message'] : 'Order Imported Successfully.';
			else 
			$json['message'] = isset($response['message']) ? $response['message'] : 'No new Orders Found.';
		} else {
			$json['success'] = false;
			$json['message'] = $response['message'];
		}
		 $this->response->setOutput(json_encode($json));
	}

}

?>